/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package core;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class Architecture {
	private ArrayList<Cluster> clusters;
	
	public Architecture(String filename){
		this.clusters=new ArrayList<Cluster>();
		try {
			DocumentBuilderFactory buildFactory=DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = buildFactory.newDocumentBuilder();
			Document document=docBuilder.parse(filename);
			document.getDocumentElement().normalize();
			NodeList clusterNodes=document.getElementsByTagName("cluster");
			for(int i=0;i<clusterNodes.getLength();i++){
				ArrayList<String> snps=new ArrayList<String>();
				Node clusterNode=clusterNodes.item(i);
				String tagSNP=clusterNode.getAttributes().getNamedItem("tagSNP").getNodeValue();
				if(clusterNode.getNodeType() == Node.ELEMENT_NODE){
                    Element clusterElement = (Element)clusterNode;
                    NodeList snpNodes = clusterElement.getElementsByTagName("SNP");
                    for(int j=0;j<snpNodes.getLength();j++){
                    	Element snpElement = (Element)snpNodes.item(j);
                    	NodeList snp = snpElement.getChildNodes();
                    	String id=snp.item(0).getNodeValue();
                    	snps.add(id);
                    }
				}
				this.clusters.add(new Cluster(snps,tagSNP));
			}
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<Cluster> getClusters(){
		return this.clusters;
	}
	
	public void print(){
		for(Cluster cluster:this.clusters){
			System.out.println("Cluster: "+cluster.getTagSNP());
			for(String id:cluster.getSnpIds())
				System.out.println(id);
		}
	}
}
