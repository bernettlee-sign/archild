/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package core;

import java.io.IOException;

import com.trolltech.qt.QSignalEmitter.Signal0;
import com.trolltech.qt.QSignalEmitter.Signal1;
import com.trolltech.qt.QSignalEmitter.Signal3;
import com.trolltech.qt.core.QRunnable;

import core_server.LinkageDisequilibrium;
import core_server.Server;
import exceptions.LinkageDisequilibriumException;
import exceptions.ServerException;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class ProcessingThreadLinkage extends QRunnable{
	public Signal0 datasetLoaded;
	public Signal1<String> error;
	private LinkageDisequilibrium ld;
	String haploviewPath;
	String pedFilename;
	String infoFilename;
	String haploviewFilename;
	String prefix;
	String chr;
	String genomeBuild;
	String freqFilename;
	String workingDir;
	boolean computeLD;
	
	public ProcessingThreadLinkage(LinkageDisequilibrium ld,String haploviewPath,String pedFilename,
			String infoFilename,String filename,String prefix,String chr,String genomeBuild,
			String freqFilename,String workingDir){
		this.datasetLoaded=new Signal0();
		this.error=new Signal1<String>();
		this.ld=ld;
		this.haploviewPath=haploviewPath;
		this.pedFilename=pedFilename;
		this.infoFilename=infoFilename;
		this.haploviewFilename=filename;
		this.prefix=prefix;
		this.chr=chr;
		this.genomeBuild=genomeBuild;
		this.freqFilename=freqFilename;
		this.computeLD=true;
		this.workingDir=workingDir;
	}
	
	public ProcessingThreadLinkage(LinkageDisequilibrium ld,
			String filename,String prefix,String chr,String genomeBuild,String freqFilename,
			String infoFilename,String workingDir){
		this.datasetLoaded=new Signal0();
		this.error=new Signal1<String>();
		this.ld=ld;
		this.haploviewFilename=filename;
		this.prefix=prefix;
		this.chr=chr;
		this.genomeBuild=genomeBuild;
		this.computeLD=false;
		this.freqFilename=freqFilename;
		this.infoFilename=infoFilename;
		this.workingDir=workingDir;
	}
	
	public void run(){
		try{
			if(this.computeLD==true)
				this.ld.computeLD(this.haploviewPath,this.pedFilename,
						this.infoFilename,this.haploviewFilename,this.workingDir);
			this.ld.uploadToMySQL(this.prefix,this.haploviewFilename,this.chr,this.infoFilename,
					this.genomeBuild,this.freqFilename,this.workingDir);
			this.datasetLoaded.emit();
		}catch(LinkageDisequilibriumException e){
			this.error.emit(e.getMessage());
		}catch(Exception e){
			this.error.emit(e.getMessage());
		}
	}
}
