/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package core;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import com.trolltech.qt.core.QRunnable;

import core_server.Server;
import exceptions.ServerException;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class ProcessingThreadArchitecture extends QRunnable{
	private String connString;
	private String type;
	private RequestKey requestKey;
	private String name;
	private Server server;
	private Signal3<RequestKey,String,String> architectureComputed;
	private Signal1<String> error;
	
	public ProcessingThreadArchitecture(Server server,String connString,String type,RequestKey requestKey,String name){
		this.connString=connString;
		this.architectureComputed=new Signal3<RequestKey,String,String>();
		this.error=new Signal1<String>();
		this.type=type;
		this.requestKey=requestKey;
		this.name=name;
		this.server=server;
	}
	
	public void run(){
		try{
			this.server.handleRequest(this.connString);
		}catch(IOException e) {
			e.printStackTrace();
		}catch(ServerException e){
			this.error.emit(e.getMessage());
		}catch(Exception e){
			this.error.emit(e.getMessage());
		}
		this.architectureComputed.emit(requestKey,name,type);
	}
	
	public Signal1<String> getError(){
		return this.error;
	}
	
	public Signal3<RequestKey,String,String> getGeneArchitectureComputed(){
		return this.architectureComputed;
	}
}
