/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package core_server;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class SNP {
	/**
	 * position of the SNP in the current genome build
	 */
	int position;
	/**
	 * chromosome on which the SNP is located
	 */
	String chromosome;
	/**
	 * SNP id
	 */
	String id;
	/**
	 * Constructs an object of type SNP from position, chromosome and id info
	 * @param position position of the SNP in the current genome build
	 * @param chromosome chromosome on which the SNP is located
	 * @param id SNP
	 */
	public SNP(int position,String chromosome,String id){
		this.position=position;
		this.chromosome=chromosome;
		this.id=id;
	}
	/**
	 * Construct an object of type SNP from the ID
	 * @param conn connection parameters
	 * @param id SNP ID
	 */
	public SNP(MySQLConnection conn,String id) throws SQLException{
		Statement stmt=null;
		ResultSet rs=null;
		try{
			stmt = conn.getConnection().createStatement();
			String cmd="SELECT chr,position FROM "+conn.getMapTable()+" WHERE rs='"+id+"'";
			rs = stmt.executeQuery(cmd);	
			while(rs.next()){
				this.position=rs.getInt("position");
				this.chromosome=rs.getString("chr");
				this.id=id;
			}
			rs.close();
			stmt.close();
		}catch (SQLException e) {
		    e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw e;
		}
	}
	/**
	 * Prints an object of type SNP in the format "id chromosome:position"
	 */
	public void print(){
		System.out.println(this.id+" "+this.chromosome+":"+this.position);
	}
	/**
	 * Returns the chromosome on which the SNP is located
	 * @return chromosome on which the SNP is located
	 */
	public String getChromosome(){
		return this.chromosome;
	}
	/**
	 * Returns the ID of the SNP
	 * @return SNP ID
	 */
	public String getId(){
		return this.id;
	}
	/**
	 * Returns the position of the SNP in the current genome build
	 * @return SNP position in the current genome build
	 */
	public int getPosition(){
		return this.position;
	}
	/**
	 * Converts the SNP in a string in the format "id"
	 */
	public String toString(){
		return id;
	}
	/**
	 * Compares two strings
	 * @param snp comparison SNP
	 * @return true if the two SNPs have the same ID, false if the two SNPs have different IDs
	 */
	public boolean equals(SNP snp){
		if(this.id.compareTo(snp.getId())==0)
			return true;
		else
			return false;
	}
	/**
	 * Returns list of SNP in the kbp region from the selected SNP
	 * @param conn connection parameters
	 * @param kbp kilo base pair region
	 * @return list of SNPs located in a plus/minus kbp region across the selected SNP
	 */
	public ArrayList<SNP> getNeighboringSNPs(MySQLConnection conn,int kbp) throws SQLException{
		int bp=1000*kbp;
		ArrayList<SNP> snps=new ArrayList<SNP>();
		Statement stmt=null;
		ResultSet rs=null;
		try{
			stmt = conn.getConnection().createStatement();
			rs = stmt.executeQuery("SELECT rs FROM "+conn.getMapTable()+" WHERE chr='"+this.chromosome+
					"' AND POSITION_"+conn.getGenomeBuild()+">"+(this.position-bp)+" AND POSITION_"+conn.getGenomeBuild()+"<"+(this.position+bp));		
			while(rs.next()){
				String id=rs.getString("rs");
				SNP snp=new SNP(conn,id);
				snps.add(snp);
			}
			rs.close();
			stmt.close();
		}catch (SQLException e) {
		    e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw e;
		}
		return snps;
	}
	/**
	 * Returns list of SNP in LD with the selected SNP (rsquared)
	 * @param conn connection parameters
	 * @param maf minor allele frequency threshold
	 * @return list of SNPs in LD with the selected SNP (rsquared)
	 */
	public ArrayList<SNP> getSNPsInLD(MySQLConnection conn,double maf) throws SQLException{
		ArrayList<SNP> snps=new ArrayList<SNP>();
		snps.add(this);
		Statement stmt=null;
		ResultSet rs=null;
		try{
			stmt = conn.getConnection().createStatement();
			rs = stmt.executeQuery("SELECT rs1,rs2 FROM "+conn.getLdTableAllPairs()+" WHERE (rs1='"+this.id+
					"' OR rs2='"+this.id+"') ORDER BY rsquared DESC");
			while(rs.next()){
				String id1=rs.getString("rs1");
				String id2=rs.getString("rs2");
				SNP snp;
				double mafSNP=0;
				if(id1.compareTo(this.id)!=0){
					snp=new SNP(conn,id1);
					Statement stmt2 = conn.getConnection().createStatement();
					ResultSet rs2 = stmt2.executeQuery("SELECT maf FROM "+conn.getMapTable()+" WHERE (rs='"+id1+"')");
					while(rs2.next())
						mafSNP=rs2.getDouble("maf");
					rs2.close();
					stmt2.close();
				}
				else{
					snp=new SNP(conn,id2);
					Statement stmt2 = conn.getConnection().createStatement();
					ResultSet rs2 = stmt2.executeQuery("SELECT maf FROM "+conn.getMapTable()+" WHERE (rs='"+id2+"')");
					while(rs2.next())
						mafSNP=rs2.getDouble("maf");
					rs2.close();
					stmt2.close();
				}
				if(mafSNP>=maf)
					snps.add(snp);
			}
			rs.close();
			stmt.close();
		}catch (SQLException e) {
		    e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw e;
		}
		return snps;
	}
	/**
	 * Returns the LD between the selected SNP and the comparison SNP (rsquared)
	 * @param conn connection parameters
	 * @param snp comparison SNP
	 * @return LD between the selected SNP and the comparison SNP (rsquared)
	 */
	public double getLD(MySQLConnection conn,SNP snp) throws SQLException{
		if(this.id.compareTo(snp.getId())==0)
			return 1;
		Statement stmt=null;
		ResultSet rs=null;
		try{
			stmt = conn.getConnection().createStatement();
			rs = stmt.executeQuery("SELECT rsquared FROM "+conn.getLdTableAllPairs()+" WHERE (rs1='"+this.id+"' " +
					"AND rs2='"+snp.getId()+"') OR (rs1='"+snp.getId()+"' AND rs2='"+this.getId()+"')");		
			while(rs.next()){
				double rsquared=rs.getDouble("rsquared");
				return rsquared;
			}
			rs.close();
			stmt.close();
		}catch (SQLException e) {
		    e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw e;
		}
		return Double.NaN;
	}
	/**
	 * Returns the cluster containing the SNP
	 * @param conn connection parameters
	 * @return the LD block containing the SNP
	 */
	public Cluster getCluster(MySQLConnection conn) throws SQLException{
		Statement stmt;
		ResultSet rs;
		try{
			// Get blocks for SNP
			stmt = conn.getConnection().createStatement();
			rs = stmt.executeQuery("SELECT block,chr FROM "+conn.getSnpsBlocksTable()
					+" WHERE rs='"+this.getId()+"'");	
			if(!rs.isBeforeFirst()){
				Cluster cluster=new Cluster(this);
				return cluster;
			}
			while(rs.next()){
				int block=rs.getInt("block");
				String chr=rs.getString("chr");
				Cluster cluster=this.getSNPsBlock(conn, block, chr);
				return cluster;
			}
			rs.close();
			stmt.close();			
		}catch (SQLException e) {
		    e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw e;
		}
	    return null;
	}
	/**
	 * Returns the cluster corresponding to a block number and a chromosome
	 * @param conn connection parameters
	 * @param block block number in the database
	 * @param chromosome chromosome in which the block is located
	 * @return cluster number "block" located on chromosome "chromosome"
	 */
	private Cluster getSNPsBlock(MySQLConnection conn,int block,String chromosome) throws SQLException{
		Statement stmt;
		ResultSet rs;
		try{
			ArrayList<SNP> snpsInBlock=new ArrayList<SNP>();
			stmt=conn.getConnection().createStatement();
			rs=stmt.executeQuery("SELECT rs FROM "+conn.getSnpsBlocksTable()+" WHERE block="+
					block+" AND chr='"+chromosome+"'");
			while(rs.next()){
				String id=rs.getString("rs");
				SNP element=new SNP(conn,id);
				snpsInBlock.add(element);
			}
				
			// Get tag SNP
			String tagID = null;
			stmt=conn.getConnection().createStatement();
			rs=stmt.executeQuery("SELECT tag_snp FROM "+conn.getBlocksTable()+" WHERE block="+
				block+" AND chr='"+chromosome+"'");
			while(rs.next()){
				tagID=rs.getString("tag_snp");
			}
			rs.close();
			stmt.close();
			// Create cluster
			SNP tagSNP=new SNP(conn,tagID);
			Cluster cluster=new Cluster(snpsInBlock,tagSNP);
			return cluster;
		}catch (SQLException e) {
			e.printStackTrace();
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
			return null;
		}
	}
	
	public static boolean exists(MySQLConnection conn,String id) throws SQLException{
		Statement stmt=null;
		ResultSet rs=null;
		try{
			stmt = conn.getConnection().createStatement();
			String cmd="SELECT chr,position FROM "+conn.getMapTable()+" WHERE rs='"+
					id+"'";
			rs = stmt.executeQuery(cmd);		
			if(!rs.isBeforeFirst()){
				return false;
			}
			while(rs.next()){
				int position=rs.getInt("position");
				if(rs.wasNull())	//No position available for the SNP
					return false;
			}
			rs.close();
			stmt.close();
		}catch (SQLException e) {
		    e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw e;
		}
		return true;
	}
}
