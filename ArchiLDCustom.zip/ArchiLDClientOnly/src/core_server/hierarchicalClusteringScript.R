clusterDataHierarchically<-function(LD_matrix,image_filename,ordered_snps_filename,width,height){
	data<-read.table(LD_matrix,sep='\t',header=TRUE,row.names=1);
	distance<-as.dist(1-data,diag=TRUE);
	png(image_filename,width=width,height=height);
	fit<-hclust(distance,method="average");
	par(mar=c(2,1,0,6));
	plot(as.dendrogram(fit),horiz=TRUE);
	dev.off();
	ordered_snps<-rev(fit$labels[fit$order]);
	write.table(ordered_snps,ordered_snps_filename,quote=FALSE,row.names=FALSE,col.names=FALSE)
}
args=commandArgs(TRUE)
#for(i in 1:length(args)){
# eval(parse(text=args[[i]]))
#}
LD_matrix=args[1];
image_filename=args[2];
width=as.numeric(args[3]);
height=as.numeric(args[4]);
ordered_snps_filename=args[5];


print(LD_matrix)
print(image_filename)
print(ordered_snps_filename)
print(width)
print(height)
clusterDataHierarchically(LD_matrix,image_filename,ordered_snps_filename,width,height)
