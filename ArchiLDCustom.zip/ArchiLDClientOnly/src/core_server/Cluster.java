/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package core_server;

import java.util.ArrayList;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class Cluster{
	/**
	 * List of SNPs
	 */
	protected ArrayList<SNP> SNPs;
	/**
	 * Tag SNP
	 */
	protected SNP tagSNP;
	
	/**
	 * Constructs a cluster from a single SNP
	 * @param snp singleton SNP
	 */
	public Cluster(SNP snp){
		this.SNPs=new ArrayList<SNP>();
		this.SNPs.add(snp);
		tagSNP=snp;
	}
	/**
	 * Constructs a cluster from another cluster
	 * @param cluster cluster to copy
	 */
	public Cluster(Cluster cluster){
		this.SNPs=cluster.SNPs;
		this.tagSNP=cluster.tagSNP;
	}
	/**
	 * Constructs a cluster from a list of SNPs and a tag SNP
	 * @param SNPs list of SNPs
	 * @param tagSNP tag SNP
	 */
	public Cluster(ArrayList<SNP> SNPs,SNP tagSNP){
		this.SNPs=SNPs;
		this.tagSNP=tagSNP;
	}
	/**
	 * Returns the tag SNP of the LD block
	 * @return tag SNP
	 */
	public SNP getTagSNP(){
		return this.tagSNP;
	}
	/**
	 * Returns all the SNPs belonging to the cluster
	 * @return SNPS belonging to the cluster
	 */
	public ArrayList<SNP> getSNPs(){
		return this.SNPs;
	}
	/**
	 * Converts the cluster to a string of the format "tagSNP [list of SNPs]"
	 */
	public String toString(){
		return this.tagSNP+" "+this.SNPs;
	}
	/**
	 * Compares two objects of type Cluster, the clusters are considered equal if the have the same tag SNP
	 */
	@Override
	public boolean equals(Object obj) {
		if(this.tagSNP.equals(((Cluster)obj).getTagSNP()))
			return true;
		else
			return false;
	}
}
