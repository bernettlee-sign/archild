/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package core_server;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class Gene {
	/**
	 * ArrayList containing gene IDs in different formats {entrez_geneid,genbank_accession,mrna_accession,protein_accession,swissprot_accession,swissprot_id,symbol}
	 */
	ArrayList<GeneID> geneIDs;
	/**
	 * minimum transcription start site across all transcripts associated to the same entrez_geneid
	 */
	int minTxStart;
	/**
	 * maximum transcription end site across all transcripts associated to the same entrez_geneid
	 */
	int maxTxEnd;
	/**
	 * chromosome on which the gene is located
	 */
	String chromosome;
	/**
	 * Constructs a gene from an ID
	 * @param conn connection parameters
	 * @param format format in which the gene ID is codified {entrez_geneid,genbank_accession,mrna_accession,protein_accession,swissprot_accession,swissprot_id,symbol}
	 * @param name gene ID
	 */
	public Gene(MySQLConnection conn,String format,String name) throws SQLException{
		this.geneIDs=new ArrayList<GeneID>();
		Statement stmt=null;
		ResultSet rs=null;
		// Set IDs
		try{
			stmt = conn.getConnection().createStatement();
			String cmd="SELECT DISTINCT gm1.value,gm1.name FROM "+conn.getGeneMetadataTable()+" as gm1 " +
					"left join "+conn.getGeneMetadataTable()+" as gm2 on gm1.id=gm2.id " +
					"left join "+conn.getGeneTable()+" as g on g.id=gm1.id "+
					"where gm2.name='"+format+"' "+
					"and gm2.value='"+name+"' "+
					"and g.genome_build='"+conn.getGenomeBuild()+"'";
			rs = stmt.executeQuery(cmd);
			while(rs.next()){
				String format_id=rs.getString("gm1.name");
				String name_id=rs.getString("gm1.value");
				GeneID id=new GeneID(format_id,name_id);
				this.geneIDs.add(id);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		}
		// Set transcription start/end using the entrez_id
		try{
			ArrayList<String> entrez_id=this.getIDs("entrez_geneid");
			String cmd="SELECT `min(transcript_start)` as min_tx_start," +
					"`max(transcript_end)` as max_tx_end,chromosome from "+
					conn.getEntrezGenesTable()+" where entrez_id='"+entrez_id.get(0)+"' and genome_build='"+conn.getGenomeBuild()+"'";
			rs=stmt.executeQuery(cmd);
			while(rs.next()){
				this.minTxStart=rs.getInt("min_tx_start");
				this.maxTxEnd=rs.getInt("max_tx_end");
				this.chromosome=rs.getString("chromosome").replaceFirst("chr", "");
			}
			rs.close();
			stmt.close();
		}catch (SQLException e) {
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw e;
		}
	}
	/**
	 * This method prints an object of type Gene in the format Format:ID
	 */
	public void print(){
		for(GeneID gid:geneIDs)
			System.out.println(gid.getFormat()+": "+gid.getName());
		System.out.println("TSS: "+this.minTxStart);
		System.out.println("TSE: "+this.maxTxEnd);
	}
	/**
	 * Returns the list of all the IDs in a particular format associated to the gene
	 * @param format format of the IDs desired {entrez_geneid,genbank_accession,mrna_accession,protein_accession,swissprot_accession,swissprot_id,symbol}
	 * @return ArrayList of IDs in the format desired
	 */
	public ArrayList<String> getIDs(String format){
		ArrayList<String> ids=new ArrayList<String>();
		for(GeneID gid:geneIDs)
			if(gid.getFormat().compareTo(format)==0)
				ids.add(gid.getName());
		return ids;
	}
	/**
	 * Returns the minimum transcription start site across all transcripts associated to the same entrez_geneid
	 * @return minimum transcription start site
	 */
	public int getMinTxStart(){
		return this.minTxStart;
	}
	/**
	 * Returns the maximum transcription start end across all transcripts associated to the same entrez_geneid
	 * @return maximum transcription start end
	 */
	public int getMaxTxEnd(){
		return this.maxTxEnd;
	}
	/**
	 * Returns the chromosome on which the gene is located
	 * @return chromosome on which the gene is located
	 */
	public String getChromosome(){
		return this.chromosome;
	}
	/**
	 * Returns the list of the SNPs located in the kbp region across the gene
	 * @param conn connection parameters
	 * @param kbp kilo base pairs across the transcription region
	 * @param maf minor allele frequency threshold
	 * @return list of SNPs located in the kbp region across the gene
	 */
	public ArrayList<SNP> getSNPs(MySQLConnection conn,int kbp,double maf) throws SQLException{
		int bp=1000*kbp;
		ArrayList<SNP> snps=new ArrayList<SNP>();
		Statement stmt=null;
		ResultSet rs=null;
		try{
			stmt = conn.getConnection().createStatement();
			rs = stmt.executeQuery("SELECT rs FROM "+conn.getMapTable()+" WHERE chr='"+this.chromosome+
					"' AND POSITION"+">"+(this.minTxStart-bp)+" AND POSITION"+"<"+(this.maxTxEnd+bp)+" AND maf>="+maf);		
			while(rs.next()){
				String id=rs.getString("rs");
				SNP snp=new SNP(conn,id);
				snps.add(snp);
			}
			rs.close();
			stmt.close();
		}catch (SQLException e) {
		    e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw e;
		}
		return snps;
	}
	
	public static boolean exists(MySQLConnection conn,String name,String format) throws SQLException{
		Statement stmt=null;
		ResultSet rs=null;
		String entrezID="";
		try{
			stmt = conn.getConnection().createStatement();
			rs = stmt.executeQuery("SELECT DISTINCT gm1.value,gm1.name FROM "+conn.getGeneMetadataTable()+" as gm1 " +
				"left join "+conn.getGeneMetadataTable()+" as gm2 on gm1.id=gm2.id " +
				"left join "+conn.getGeneTable()+" as g on g.id=gm1.id "+
				"where gm2.name='"+format+"' "+
				"and gm2.value='"+name+"' "+
				"and g.genome_build='"+conn.getGenomeBuild()+"'");
			if(!rs.isBeforeFirst())
				return false;
			while(rs.next()){
				String formatID=rs.getString("gm1.name");
				String nameID=rs.getString("gm1.value");
				GeneID id=new GeneID(formatID,nameID);
				if(formatID.compareTo("entrez_geneid")==0)
					entrezID=nameID;
			}
		}catch (SQLException e) {
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw e;
		}
		try{
			rs=stmt.executeQuery("SELECT `min(transcript_start)` as min_tx_start," +
					"`max(transcript_end)` as max_tx_end,chromosome from "+
					conn.getEntrezGenesTable()+" where entrez_id='"+entrezID+"' and genome_build='"+conn.getGenomeBuild()+"'");
			if(!rs.isBeforeFirst())
				return false;
			rs.close();
			stmt.close();
		}catch (SQLException e) {
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw e;
		}
		return true;
	}
	
	public static boolean existsInDataset(MySQLConnection conn,String name,String format,
			String prefix,int maxDist) throws SQLException{
		Statement stmt=null;
		ResultSet rs=null;
		String entrezID="";
		try{
			stmt = conn.getConnection().createStatement();
			rs = stmt.executeQuery("SELECT DISTINCT gm1.value,gm1.name FROM "+conn.getGeneMetadataTable()+" as gm1 " +
				"left join "+conn.getGeneMetadataTable()+" as gm2 on gm1.id=gm2.id " +
				"left join "+conn.getGeneTable()+" as g on g.id=gm1.id "+
				"where gm2.name='"+format+"' "+
				"and gm2.value='"+name+"' "+
				"and g.genome_build='"+conn.getGenomeBuild()+"'");
			if(!rs.isBeforeFirst())
				return false;
			while(rs.next()){
				String formatID=rs.getString("gm1.name");
				String nameID=rs.getString("gm1.value");
				GeneID id=new GeneID(formatID,nameID);
				if(formatID.compareTo("entrez_geneid")==0)
					entrezID=nameID;
			}
		}catch (SQLException e) {
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw e;
		}
		try{
			int start=0;
			int end=0;
			String chr="";
			rs=stmt.executeQuery("SELECT `min(transcript_start)` as min_tx_start," +
					"`max(transcript_end)` as max_tx_end,chromosome from "+
					conn.getEntrezGenesTable()+" where entrez_id='"+entrezID+"' and genome_build='"+conn.getGenomeBuild()+"'");
			if(!rs.isBeforeFirst())
				return false;
			while(rs.next()){
				start=rs.getInt("min_tx_start");
				start=start-maxDist;
				end=rs.getInt("max_tx_end");
				end=end+maxDist;
				chr=rs.getString("chromosome");
				chr=chr.substring(3,chr.length());
			}
			String cmd="SELECT * FROM "+prefix+"_complete_map WHERE chr='"+chr+"' AND position>"+start+
			" AND position<"+end;
			rs=stmt.executeQuery(cmd);
			if(!rs.isBeforeFirst())
				return false;
			rs.close();
			stmt.close();
		}catch (SQLException e) {
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw e;
		}
		return true;
	}
}
