/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package core_server;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import exceptions.ConnectionErrorException;
import exceptions.ConnectionLostException;
import exceptions.NoClusterInGeneException;
import exceptions.NoSNPInGeneException;
import exceptions.NotEnoughClustersToBuildHierarchicalTree;
import exceptions.NotFoundInDatasetException;
import exceptions.ServerException;
import exceptions.SexChromosomesNotCoveredException;
import exceptions.TooManySNPsException;
import gui.MainWindow;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class Server{
	private static final long serialVersionUID=1L;
	private final static String _TYPE="type";
	private final static String _DATASET="dataset";
	private final static String _MAF="maf";
	private final static String _FORMAT="format";
	private final static String _ID="id";
	private final static String _MAXDIST="maxdist";
	private final static String _RS="rs";
	private final static String _SINGLETONS="singletons";
	private final static String _GENOMEBUILD="genomebuild";
	private final static String _HIERARCHICAL="hierarchical";
	private final static String _REQUESTKEY="requestkey";
	private final static String _HAPLOTYPES="haplotypes";
	private final static String _COLORBYFREQ="colorbyfreq";
	private String host;
	private String database;
	private String username;
	private String password;
	private String geneMetadataTable;
	private String geneTable;
	private String entrezGeneTable;
	private String workingDir;
	private String RPath;
	private String HaploviewPath;
	private String prefix;
	private String prefixReduced;
	private String ancestorTable;
	private int maxNumberElementsToCluster;
	private MySQLConnection conn;
	private MainWindow mainWindow;
       
    public Server(String host,String database,String username,String password,
    		String RPath,String HaploviewPath,String workingDir,MainWindow mainWindow) throws ConnectionErrorException {
        super();
		this.host=host;
        this.database=database;
        this.username=username;
        this.password=password;
        this.geneMetadataTable="ucsc_gene_metadata";
        this.geneTable="ucsc_genes";
        this.entrezGeneTable="ucsc_entrez_genes";
        this.workingDir=workingDir;
        this.RPath=RPath;
        this.HaploviewPath=HaploviewPath;
	    this.prefix="1000_genomes_complete";
	    this.prefixReduced="1000_genomes";
	    this.maxNumberElementsToCluster=300;
	    this.ancestorTable="ucsc_ancestor";
		this.conn=new MySQLConnection(host,database,username,password,geneMetadataTable,geneTable,entrezGeneTable,
        		workingDir,RPath,maxNumberElementsToCluster,ancestorTable);
		this.mainWindow=mainWindow;
    }

	public void handleRequest(String connectionString) throws IOException, ServerException {
		try{
	        // Setup MySQL Connection
		    String type=this.getParameter(connectionString,_TYPE);
		    String format="";
		    String id="";
		    int maxDist=0;
		    String rs="";
		    boolean hierarchical=false;
		    boolean buildHaplotypes=false;
		    boolean colorByMAF=false;
		    if(type.compareTo("Gene")==0){
		    	format=this.getParameter(connectionString,_FORMAT);
		    	id=this.getParameter(connectionString,_ID).toUpperCase();
		    	maxDist=Integer.parseInt(this.getParameter(connectionString,_MAXDIST));
		    	hierarchical=Boolean.parseBoolean(this.getParameter(connectionString,_HIERARCHICAL));
		    }
		    if(type.compareTo("Region")==0){
		    	hierarchical=Boolean.parseBoolean(this.getParameter(connectionString,_HIERARCHICAL));
		    }
		    if(type.compareTo("SNP")==0){
		    	 rs=this.getParameter(connectionString,_RS);
		    }
		    String dataset=this.getParameter(connectionString,_DATASET);
		    double maf=Double.parseDouble(this.getParameter(connectionString,_MAF));	   
		    boolean singletons=Boolean.parseBoolean(this.getParameter(connectionString,_SINGLETONS));
		    String genomeBuild=this.getParameter(connectionString,_GENOMEBUILD);
		    String requestKey=this.getParameter(connectionString,_REQUESTKEY);
		    colorByMAF=Boolean.parseBoolean(this.getParameter(connectionString,_COLORBYFREQ));
		    buildHaplotypes=Boolean.parseBoolean(this.getParameter(connectionString,_HAPLOTYPES));
		    // Set ld tables
		    this.conn.setMapTable(dataset+"_complete_map");
		    this.conn.setBlocksTable(dataset+"_complete_blocks");
		    this.conn.setSnpsBlocksTable(dataset+"_complete_snps_blocks");
		    this.conn.setLdTable(dataset+"_complete_ld");
		    this.conn.setldTableAllPairs(dataset+"_ld");
		    this.conn.setGenomeBuild(genomeBuild);
		    Architecture architecture = null;
		    boolean exists=false;
		    if(type.compareTo("Gene")==0){
		    	if(Gene.existsInDataset(conn, id, format,dataset,maxDist)){
			    	Gene gene=new Gene(conn,format,id);
			    	if(gene.getChromosome().compareTo("X")==0 || gene.getChromosome().compareTo("Y")==0){
			    		throw new SexChromosomesNotCoveredException();
			    	}
			    	else{
			    		try{
				    		architecture=new Architecture(conn,gene,maxDist,dataset,id,singletons,maf,this.mainWindow,colorByMAF);
				    		if(architecture.getClusters().size()==0){
				    			if(!singletons){
				    				throw new NoClusterInGeneException();
				    			}else{
				    				throw new NoSNPInGeneException();
				    			}
				    		}
				    		else{
				    			String exportTrackFilename=conn.getWorkingDir()+requestKey+".track";
				    			if(hierarchical==false){
				    				architecture.exportUcscMergedTracks(exportTrackFilename);
				    				String exportXmlFilename=conn.getWorkingDir()+requestKey+".xml";
							    	architecture.exportToXml(exportXmlFilename);
				    			}
				    			else{
				    				architecture=architecture.cluster(requestKey);
				    				architecture.exportUcscDistinctTracks(exportTrackFilename);
				    				String exportXmlFilename=conn.getWorkingDir()+requestKey+".xml";
							    	architecture.exportToXml(exportXmlFilename);
				    			}
				    		}
			    		}catch(TooManySNPsException e){
			    			throw e;
			    		}catch(NotEnoughClustersToBuildHierarchicalTree e){
			    			throw e;
			    		}
			    	}
			    	exists=true;
		    	}else{
		    		exists=false;
		    	}
		    }
		    
		    if(type.compareTo("Region")==0){
	    		try{
		    		architecture=new Architecture(conn,dataset,singletons,maf,this.mainWindow,colorByMAF);
		    		if(architecture.getClusters().size()==0){
		    			if(!singletons){
		    				throw new NoClusterInGeneException();
		    			}else{
		    				throw new NoSNPInGeneException();
		    			}
		    		}
		    		else{
		    			String exportTrackFilename=conn.getWorkingDir()+requestKey+".track";
		    			if(hierarchical==false){
		    				architecture.exportUcscMergedTracks(exportTrackFilename);
		    				String exportXmlFilename=conn.getWorkingDir()+requestKey+".xml";
					    	architecture.exportToXml(exportXmlFilename);
		    			}
		    			else{
		    				architecture=architecture.cluster(requestKey);
		    				architecture.exportUcscDistinctTracks(exportTrackFilename);
		    				String exportXmlFilename=conn.getWorkingDir()+requestKey+".xml";
					    	architecture.exportToXml(exportXmlFilename);
		    			}
		    		}
	    		}catch(TooManySNPsException e){
	    			throw e;
	    		}catch(NotEnoughClustersToBuildHierarchicalTree e){
	    			throw e;
	    		}
	    	}

		    if(type.compareTo("SNP")==0){
		    	if(SNP.exists(conn, rs)){
			    	SNP snp=new SNP(conn,rs);
			    	architecture=new Architecture(conn,snp,dataset,singletons,maf,this.mainWindow,colorByMAF);
			    	String exportTrackFilename=conn.getWorkingDir()+requestKey+".track";
			    	architecture.exportUcscDistinctTracks(exportTrackFilename, rs);
			    	String exportXmlFilename=conn.getWorkingDir()+requestKey+".xml";
			    	architecture.exportToXml(exportXmlFilename);
			    	exists=true;
		    	}else{
		    		exists=false;
		    	}
		    }
		    
		    if(buildHaplotypes==true){
		    	System.out.println("Build haplotypes");
		    	// Run haplotypes
		    	String snpListFilename=conn.getWorkingDir()+requestKey+".snplist";
		    	architecture.exportSNPs(snpListFilename);
		    	String genoFilename=conn.getWorkingDir()+"permanent/"+dataset+".low_coverage.2010_09.genotypes";
		    	String prefix=conn.getWorkingDir()+requestKey;
		    	architecture.createGenotypeFileForHaploview(genoFilename,snpListFilename,prefix);
		    	String pedFilename=prefix+".ped";
		    	String infoFilename=prefix+".info";
		    	String haploFilename=prefix;
		    	String logFilename=prefix+".log";
		    	String finalHaploFilename=prefix+".haplo";
		    	String finalHaploFilenameFasta=prefix+".fasta";
		    	architecture.buildHaplotypeFile(pedFilename,infoFilename,haploFilename,logFilename);

		    	ArrayList<Haplotype> haplotypes=architecture.buildHaplotypes(haploFilename,infoFilename);
		    	boolean first=true;
		    	int counter=0;
		    	for(Haplotype haplo:haplotypes){
		    		haplo.printAlleles();
		    		if(first){
		    			haplo.export(finalHaploFilename,true,first);
		    			haplo.exportFasta(finalHaploFilenameFasta,true,first);
		    			first=false;
		    		}
		    		else{
		    			haplo.export(finalHaploFilename,true,first);
		    			haplo.exportFasta(finalHaploFilenameFasta,true,first);
		    		}
		    		counter=counter+1;
		    	}
		    	Haplotype chimp=architecture.getAncestorHaplotype("chimp");
		    	Haplotype orderedChimp=chimp.orderHaplotype(haplotypes.get(0));
		    	orderedChimp.printAlleles();
		    	orderedChimp.export(finalHaploFilename,true,false);
		    	orderedChimp.exportFasta(finalHaploFilenameFasta,true,false);
		    	
		    	Haplotype orang=architecture.getAncestorHaplotype("orang");
		    	Haplotype orderedOrang=orang.orderHaplotype(haplotypes.get(0));
		    	orderedOrang.printAlleles();
		    	orderedOrang.export(finalHaploFilename,true,false);
		    	//orderedOrang.exportFasta(finalHaploFilenameFasta,"anc_orang",true,false);
		    	
		    	Haplotype macaque=architecture.getAncestorHaplotype("macaque");
		    	Haplotype orderedMacaque=macaque.orderHaplotype(haplotypes.get(0));
		    	orderedMacaque.printAlleles();
		    	orderedMacaque.export(finalHaploFilename,true,false);
		    	//orderedMacaque.exportFasta(finalHaploFilenameFasta,"anc_macaque",true,false);
		    	
		    	for(Haplotype haplo:haplotypes){
		    		haplo.printAlleles();
		    		System.out.println(orderedChimp.countDifferences(haplo));
		    	}
		    	
		    	EvolutionTree tree=new EvolutionTree(orderedChimp,haplotypes);
		    }
	       // response.setContentType("application/octet-stream");
	        //ObjectOutputStream oos=new ObjectOutputStream(response.getOutputStream());  
	        if(!exists){
	        	if(type.compareTo("Gene")==0)
	        		throw new NotFoundInDatasetException("Gene");
	        	if(type.compareTo("SNP")==0)
	        		throw new NotFoundInDatasetException("SNP");
	        }
	        System.gc();
	        architecture=null;
		}catch(SQLException e){
			throw new ConnectionLostException(e);
		}
	}
	
	private String getParameter(String connectionString,String parameter){
		String unformattedParameters=connectionString.substring(connectionString.indexOf('?')+1);
		String[] elements=unformattedParameters.split("&");
		String value="Not found";
		String name="";
		for(String element:elements){
			String[] temp=element.split("=");
			name=temp[0];
			value=temp[1];
			if(name.compareTo(parameter)==0)
				return value;
		}
		System.out.println(parameter+" "+value);
		return value;
	}
	
	public String getRPath(){
		return this.RPath;
	}
	
	public String getHaploviewPath(){
		return this.HaploviewPath;
	}
	
	public String getWorkingDir(){
		return this.workingDir;
	}

	public MySQLConnection getMySQLConnection(){
		return this.conn;
	}
}
