/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package core_server;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class Haplotype {
	String name;
	ArrayList<Locus> alleles;
	double freq;
	
	public Haplotype(Haplotype haplo){
		this.name=haplo.name;
		this.alleles=new ArrayList<Locus>();
		for(Locus locus:haplo.getLoci())
			this.alleles.add(new Locus(locus.getAllele(),locus.getMarker()));
		this.freq=haplo.freq;
	}
	
	public Haplotype(ArrayList<Locus> alleles,double freq,String name){
		this.name=name;
		this.alleles=new ArrayList<Locus>();
		for(Locus locus:alleles)
			this.alleles.add(new Locus(locus.getAllele(),locus.getMarker()));
		this.freq=freq;
	}
	
	public Haplotype(String stringAlleles,ArrayList<SNP> snps,double freq,String name) {
		this.name=name;
		System.out.println("Haplotype");
		this.alleles=new ArrayList<Locus>();
		Character allele;
		for(int i=0;i<stringAlleles.length();i++){
			switch(stringAlleles.charAt(i)){
				case '1':	allele='A';
							break;
				case '2':	allele='C';
							break;
				case '3':	allele='G';
							break;
				case '4':	allele='T';
							break;
				default: 	allele='N';
							break;
			}
			this.alleles.add(new Locus(allele,snps.get(i)));
		}
		this.freq=freq;
	}
	
	/**
	 * Return ancestor haplotype for the list of SNPs
	 * @param snps list of SNPs
	 */
	public Haplotype(MySQLConnection conn,ArrayList<SNP> snps,String ancestor,String name){
		this.name=name;
		this.alleles=new ArrayList<Locus>();
		Statement stmt;
		ResultSet rs;
		try{
			for(SNP snp:snps){
				stmt=conn.getConnection().createStatement();
				rs=stmt.executeQuery("SELECT human_strand,"+ancestor+"_allele FROM "+conn.getAncestorTable()+
						" WHERE snp='"+snp.getId()+"'");
				boolean exists=false;
				while(rs.next()){
					exists=true;
					if(rs.getString("human_strand")!=null && rs.getString(ancestor+"_allele")!=null){
						Character humanStrand=rs.getString("human_strand").charAt(0);
						Character ancestorAllele=rs.getString(ancestor+"_allele").charAt(0);
						if(humanStrand.compareTo('-')==0){
							this.alleles.add(new Locus(this.getComplementaryAllele(ancestorAllele),snp));
						}
						else
							this.alleles.add(new Locus(ancestorAllele,snp));
					}else{
						this.alleles.add(new Locus('N',snp));
					}
				}
				if(exists==false)
					this.alleles.add(new Locus('N',snp));
				rs.close();
				stmt.close();
			}
		}catch(SQLException e){
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		}
		this.freq=1;
	}
	
	public void printAlleles(){
		for(Locus allele:this.alleles)
			System.out.print(allele.getAllele()+" ");		
		System.out.print("\n");
	}
	
	public void printMarkers(){
		for(Locus allele:this.alleles)
			System.out.print(allele.getMarker().getId()+" ");
		System.out.print("\n");
		System.out.print("Freq:");
		System.out.println(this.freq);
	}
	
	private Character getComplementaryAllele(Character allele){
		Character complementaryAllele=allele;
		switch(allele){
			case 'A':	complementaryAllele='T';
						break;
			case 'T':	complementaryAllele='A';
						break;
			case 'C':	complementaryAllele='G';
						break;
			case 'G':	complementaryAllele='C';
						break;
			default:	complementaryAllele=allele;
						break;
		}
		return complementaryAllele;
	}

	public Haplotype orderHaplotype(Haplotype template){
		double freq=this.freq;
		String name=this.name;
		ArrayList<Locus> orderedAlleles=new ArrayList<Locus>();
		for(Locus tempAllele:template.alleles){
			for(Locus allele:this.alleles){
				if(allele.equals(tempAllele)){
					orderedAlleles.add(allele);
					break;
				}
			}		
		}
		return new Haplotype(orderedAlleles,freq,name);
	}
	
	public void export(String filename,boolean append,boolean first){
		try{
			BufferedWriter writer=null;
			if(first)
				writer=new BufferedWriter(new FileWriter(filename,false));
			else
				writer=new BufferedWriter(new FileWriter(filename,true));
			if(first){
				writer.write("haplo_name");
				for(Locus allele:this.alleles)
					writer.write("\t"+allele.getMarker().getId());
				writer.write("\n");
			}
			writer.write(this.name);
			for(Locus allele:this.alleles)
				writer.write("\t"+allele.getAllele().toString());
			writer.write("\n");
			writer.close();	
		}catch(IOException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void exportFasta(String filename,boolean append,boolean first){
		try{
			BufferedWriter writer=null;
			if(first)
				writer=new BufferedWriter(new FileWriter(filename,false));
			else
				writer=new BufferedWriter(new FileWriter(filename,true));
			writer.write("> "+this.name+"\n");
			for(Locus allele:this.alleles)
				writer.write(allele.getAllele().toString());
			writer.write("\n");
			writer.close();	
		}catch(IOException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	/**
	 * Compares two haplotypes and return the number of differences. The two haplotypes need to be ordered in the same way
	 * @param haplo
	 * @return number of differences between the two haplotypes
	 */
	public int countDifferences(Haplotype haplo){
		int numDifferences=0;
		ArrayList<Locus> alleles=haplo.getLoci();
		for(int i=0;i<alleles.size();i++){
			if(!alleles.get(i).getMarker().equals(this.alleles.get(i).getMarker()))
				return -1;
			if(alleles.get(i).getAllele().compareTo(this.alleles.get(i).getAllele())!=0)
				numDifferences++;
		}
		return numDifferences;
	}
	
	public ArrayList<Locus> getLoci(){
		return this.alleles;
	}
	
	public ArrayList<Haplotype> findClosest(ArrayList<Haplotype> haplotypes){
		ArrayList<Haplotype> closestHaplotypes=new ArrayList<Haplotype>();
		int minNumDifferences=Integer.MAX_VALUE;
		for(int i=0;i<haplotypes.size();i++){
			int numDifferences=this.countDifferences(haplotypes.get(i));
			if(numDifferences<minNumDifferences){
				closestHaplotypes.clear();
				closestHaplotypes.add(haplotypes.get(i));
				minNumDifferences=numDifferences;
			}
			else if(numDifferences==minNumDifferences){
				closestHaplotypes.add(haplotypes.get(i));
				minNumDifferences=numDifferences;
			}
		}
		return closestHaplotypes;
	}
	
	public String getName(){
		return this.name;
	}
	
	public ArrayList<SNP> getDifferences(Haplotype haplo){
		ArrayList<SNP> differences=new ArrayList<SNP>();
		ArrayList<Locus> alleles=haplo.getLoci();
		for(int i=0;i<alleles.size();i++){
			if(!alleles.get(i).getMarker().equals(this.alleles.get(i).getMarker()))
				return null;
			if(alleles.get(i).getAllele().compareTo(this.alleles.get(i).getAllele())!=0){
				differences.add(alleles.get(i).getMarker());
			}
		}
		return differences;
	}
	
	public boolean equals(Haplotype haplotype){
		for(int i=0;i<this.alleles.size();i++){
			if(!this.alleles.get(i).getAllele().equals(haplotype.getLoci().get(i).getAllele()))
				return false;
		}	
		return true;
	}
	
	public void setMarkerAllele(SNP marker,Character allele){
		for(Locus locus:this.getLoci())
			if(locus.getMarker().equals(marker))
				locus.setAllele(allele);
	}
	
	public Character getMarkerAllele(SNP marker){
		for(Locus locus:this.getLoci())
			if(locus.getMarker().equals(marker))
				return locus.getAllele();
		return null;		
	}
	
	public String toString(){
		String s="";
		for(Locus locus:this.getLoci()){
			s=s+" "+locus.getAllele();
		}
		return s;
	}
}
