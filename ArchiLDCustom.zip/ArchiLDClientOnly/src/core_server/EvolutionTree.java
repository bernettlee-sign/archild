/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package core_server;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class EvolutionTree {
	HashMap<Haplotype,ArrayList<Haplotype>> map;
	ArrayList<Node> tree;

	public EvolutionTree(Haplotype ancestor,ArrayList<Haplotype> haplotypes) {
		this.tree=new ArrayList<Node>();
		this.map=new HashMap<Haplotype,ArrayList<Haplotype>>();
		System.out.println(haplotypes.size());
		System.out.println("Building tree...");
		
		ArrayList<Haplotype> toPlace=new ArrayList<Haplotype>(haplotypes);
		System.out.println(toPlace.size());
		ArrayList<Haplotype> leaves=new ArrayList<Haplotype>();
		leaves.add(ancestor);
		int counter=0;
		while(toPlace.size()>0){
			ArrayList<Haplotype> haplotypesToPlace=new ArrayList<Haplotype>();
			for(Haplotype haplo:leaves){
				ArrayList<Haplotype> closestHaplotypes=haplo.findClosest(toPlace);
				for(Haplotype h:closestHaplotypes){
					if(!haplotypesToPlace.contains(h))
						haplotypesToPlace.add(h);
				}
			}
			for(Haplotype haplo:haplotypesToPlace){
				ArrayList<Haplotype> parents=haplo.findClosest(leaves);
				for(Haplotype parent:parents){
					ArrayList<Haplotype> children=new ArrayList<Haplotype>();
					if(map.containsKey(parent))
						children=map.get(parent);
					children.add(haplo);
					map.put(parent, children);
				}
				/*if(map.containsKey(haplo)){
					ArrayList<Haplotype> temp=map.get(haplo);
					temp.addAll(parents);
					map.put(haplo, temp);
				}else{
					ArrayList<Haplotype> temp=new ArrayList<Haplotype>();
					temp.addAll(parents);
					map.put(haplo, temp);
				}*/
				leaves.add(haplo);
			}
			
			toPlace.removeAll(haplotypesToPlace);
			counter=counter+1;
		}
		for(Haplotype key:map.keySet()){
			System.out.print("Father "+key.getName()+":");
			for(Haplotype child:map.get(key)){
				System.out.print(" "+child.getName());
				System.out.print("{ ");
				for(SNP marker:child.getDifferences(key))
					System.out.print(marker.getId()+" ");
				System.out.println("}");
			}
			System.out.print("\n");
		}
		
		// Create primary node
		try{
			for(Haplotype key:map.keySet()){
				// Handle father
				Node fatherNode=this.findNode(key);
				if(fatherNode==null){
					fatherNode=new Node(null,key,key.getName());
					this.tree.add(fatherNode);
				}
				// Handle childrens
				ArrayList<Haplotype> childrens=map.get(key);
				for(Haplotype child:childrens){
					Node childNode=this.findNode(child);
					if(childNode==null){
						childNode=new Node(fatherNode,child,child.getName());
						this.tree.add(childNode);
					}else if(childNode.getFather()==null){
						childNode.setFather(fatherNode);
					}
				}
			}
			this.addMarkers();
			this.print();
			ArrayList<Node> toCheck=new ArrayList<Node>(tree);
			
			int counterHidden=0;
			while(toCheck.size()>0){
				Node currentNode=toCheck.get(0);
				ArrayList<Node> siblings=this.findSiblings(currentNode);
				toCheck.removeAll(siblings);
				toCheck.remove(currentNode);
				for(Node sibling1:siblings)
					for(Node sibling2:siblings){
						if(!sibling1.equals(sibling2)){
							ArrayList<SNP> markers1=sibling1.getMarkers();
							ArrayList<SNP> markers2=sibling2.getMarkers();
							for(SNP marker1:markers1)
								for(SNP marker2:markers2)
									if(marker1.equals(marker2)){
										// Create node if it does not exist, link siblings to the new node, link new node to the
										// father of the old nodes
										Character alleleSibling=sibling1.getHaplotype().getMarkerAllele(marker1);
										// It inherits the haplotype of the father but with one mutation for the common locus
										Haplotype haplotype=new Haplotype(sibling1.getFather().getHaplotype().getLoci(),0,"hiddenh"+marker1.getId());
										haplotype.setMarkerAllele(marker1, alleleSibling); // I am worried that it will change the haplotype of the father
										Node hiddenNode=this.findNode(haplotype);
										if(hiddenNode==null){
											hiddenNode=new Node(sibling1.getFather(),haplotype,"hidden"+marker1.getId());
											counterHidden++;
										}
										sibling1.setFather(hiddenNode);
										sibling2.setFather(hiddenNode);
										this.tree.add(hiddenNode);
										System.out.println(sibling1.getName()+"-"+sibling2.getName()+"-"+marker1.getId());
									}
						}
					}
			}
			System.out.println("Out of the while");
			this.addMarkers();
			this.print();	
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	private Node findNode(Haplotype haplotype){
		for(Node node:this.tree)
			if(node.getHaplotype().equals(haplotype))
				return node;
		return null;
	}
	
	public void print(){
		System.out.println("Tree");
		System.out.println(this.tree.size());
		for(Node node:this.tree){
			Node father=node.getFather();
			if(father==null)
				System.out.println(node.getName()+node.getHaplotype().toString()+": no father");
			else{
				System.out.print("{");
				for(SNP marker:node.getMarkers())
					System.out.print(" "+marker.getId());
				System.out.print(" }");
				System.out.println(node.getName()+node.getHaplotype().toString()+": "+father.getName());
			}
		}
	}
	
	public void addMarkers(){
		for(Node node:this.tree){
			Node father=node.getFather();
			if(father==null)
				continue;
			ArrayList<SNP> differences=node.getHaplotype().getDifferences(father.getHaplotype());
			node.setMarkers(differences);
		}
	}
	
	public ArrayList<Node> findSiblings(Node node){
		ArrayList<Node> siblings=new ArrayList<Node>();
		for(Node toCheck:this.tree)
			if(node.getFather()==toCheck.getFather()){
				siblings.add(toCheck);
			}
		return siblings;
	}
}
