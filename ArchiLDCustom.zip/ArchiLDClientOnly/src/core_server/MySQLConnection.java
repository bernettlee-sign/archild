/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package core_server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import exceptions.ConnectionErrorException;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class MySQLConnection {
	/**
	 * MySQL connection object
	 */
	private Connection conn;
	/**
	 * MySQL host
	 */
	private String host;
	/**
	 * MySQL database
	 */
	private String db;
	/**
	 * MySQL username
	 */
	private String username;
	/**
	 * MySQL pswd;
	 */
	private String pswd;
	/**
	 * table containing positional information concerning the SNPs
	 */
	private String mapTable;
	/**
	 * table containing a list of LD blocks and their respective tag SNP
	 */
	private String blocksTable;
	/**
	 * table containing all SNPs belonging to a block and their respective block ID
	 */
	private String snpsBlocksTable;
	/**
	 * table containing LD info between tag SNPs
	 */
	private String ldTable;
	/**
	 * table containing LD info between all SNPs
	 */
	private String ldTableAllPairs;
	/**
	 * table containing ID synonyms for UCSC genes
	 */
	private String geneMetadataTable;
	/**
	 * table containing positional information on UCSC genes
	 */
	private String geneTable;
	/**
	 * table containing entrez genes and their respective TSS/TSE
	 */
	private String entrezGenesTable;
	/**
	 * table containing ancestor alleles
	 */
	private String ancestorTable;
	/**
	 * working directory in which to store temporary files and hierarchical clustering plots
	 */
	private String workingDir;
	/**
	 * prefix for all temporary files
	 */
	private String requestKey;
	/**
	 * genome build used for the analysis (it must be the same for all tables)
	 */
	private String genomeBuild;
	/**
	 * complete path to R executable
	 */
	private String RPath;
	/**
	 * complete path to Haploview executable
	 */
	private String HaploviewPath;
	/**
	 * complete path to Plink executable
	 */
	private String PlinkPath;
	/**
	 * Max number of SNPs allowed to avoid crashes
	 */
	private int maxNumberElementsToCluster;
	
	/**
	 * Constructor
	 * @param host MySQL host
	 * @param database MySQL database
	 * @param username MySQL username
	 * @param password MySQL password
	 * @param geneMetadataTable table containing gene IDs
	 * @param geneTable table containing info about genes
	 * @param entrezGenesTable table containing Entrez genes and their respective TSS/TSE
	 * @param workingDir working directory in which to store temporary files and hierarchical clustering plots
	 * @param RPath complete path to R executable
	 * @throws ConnectionErrorException 
	 */
	public MySQLConnection(String host,String database,
			String username,String password,String geneMetadataTable,String geneTable,
			String entrezGenesTable,String workingDir,String RPath,int maxNumberElementsToCluster,
			String ancestorTable) throws ConnectionErrorException{
		this.host=host;
		this.db=database;
		this.username=username;
		this.pswd=password;
		try {
			Class.forName("com.mysql.jdbc.Driver"); 
        	this.conn=DriverManager.getConnection("jdbc:mysql://"+host+":3306/"+database+"?",username,password);
		} catch (SQLException e) {
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw new ConnectionErrorException();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		this.geneMetadataTable=geneMetadataTable;
		this.geneTable=geneTable;
		this.entrezGenesTable=entrezGenesTable;
		this.workingDir=workingDir;
		this.RPath=RPath;
		this.maxNumberElementsToCluster=maxNumberElementsToCluster;
		this.ancestorTable=ancestorTable;
	}
	/**
	 * 
	 * @return a MySQL connection
	 */
	public Connection getConnection(){
		return this.conn;
	}
	/**
	 * 
	 * @return the map table associated to the analysis
	 */
	public String getMapTable(){
		return this.mapTable;
	}
	/**
	 * 
	 * @return the blocks table associated to the analysis
	 */
	public String getBlocksTable(){
		return this.blocksTable;
	}
	/**
	 * 
	 * @return the snps-blocks table associated to the analysis
	 */
	public String getSnpsBlocksTable(){
		return this.snpsBlocksTable;
	}
	/**
	 * 
	 * @return the ld table associated to the analysis (tag SNPs only)
	 */
	public String getLdTable(){
		return this.ldTable;
	}
	/**
	 * 
	 * @return the ld table associated to the analysis (all SNPs)
	 */
	public String getLdTableAllPairs(){
		return this.ldTableAllPairs;
	}
	/**
	 * 
	 * @return the gene metadata table associated to the analysis
	 */
	public String getGeneMetadataTable(){
		return this.geneMetadataTable;
	}
	/**
	 * 
	 * @return the gene table associated to the analysis
	 */
	public String getGeneTable(){
		return this.geneTable;
	}
	/**
	 * 
	 * @return the entrez genes table associated to the analysis
	 */
	public String getEntrezGenesTable(){
		return this.entrezGenesTable;
	}
	/**
	 * 
	 * @return the working directory associated to the analysis
	 */
	public String getWorkingDir(){
		return this.workingDir;
	}
	/**
	 * 
	 * @return the genome build associated to the analysis
	 */
	public String getGenomeBuild(){
		return this.genomeBuild;
	}
	/**
	 * 
	 * @return the path to the R executable
	 */
	public String getRPath(){
		return this.RPath;
	}
	/**
	 * 
	 * @return max number of SNPs allowed
	 */
	public int getMaxNumberElementsToCluster(){
		return this.maxNumberElementsToCluster;
		
	}
	/**
	 * 
	 * @return ancestor table
	 */
	public String getAncestorTable(){
		return this.ancestorTable;
	}
	/**
	 * Set map table
	 * @param mapTable map table
	 */
	public void setMapTable(String mapTable){
		this.mapTable=mapTable;
	}
	/**
	 * Set blocks table
	 * @param blocksTable blocks table
	 */
	public void setBlocksTable(String blocksTable){
		this.blocksTable=blocksTable;
	}
	/**
	 * Set snps blocks table
	 * @param snpsBlocksTable snps blocks table
	 */
	public void setSnpsBlocksTable(String snpsBlocksTable){
		this.snpsBlocksTable=snpsBlocksTable;
	}
	/**
	 * Set ld table
	 * @param ldTable ld table
	 */
	public void setLdTable(String ldTable){
		this.ldTable=ldTable;
	}
	/**
	 * Set ld table all pairs
	 * @param ldTableAllPairs ld table all pairs
	 */
	public void setldTableAllPairs(String ldTableAllPairs){
		this.ldTableAllPairs=ldTableAllPairs;
	}
	public void printConnection(){
		System.out.println(this.host+" "+this.db+" "+this.username+" "+this.pswd);
	}
	/**
	 * Set genome build
	 * @param genomeBuild genome build that must be used for the analysis
	 */
	public void setGenomeBuild(String genomeBuild){
		this.genomeBuild=genomeBuild;
	}
	
	public String getDatabase(){
		return this.db;
	}
}
