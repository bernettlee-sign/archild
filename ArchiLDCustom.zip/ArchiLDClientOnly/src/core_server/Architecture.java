/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package core_server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import exceptions.ExecutableNotFoundException;
import exceptions.NotEnoughClustersToBuildHierarchicalTree;
import exceptions.OrderedSNPsLDFileNotFound;
import exceptions.TooManySNPsException;
import gui.MainWindow;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class Architecture {
	/**
	 * ArrayList of cluster objects
	 */
	private ArrayList<Cluster> clusters;
	/**
	 * population to which the clusters are associated
	 */
	private String dataset;
	/**
	 * chromosome to which the clusters are associated
	 */
	private String chromosome;
	/**
	 * connection parameters used for the analysis
	 */
	private MySQLConnection conn;
	/**
	 * architecture name
	 */
	private String name;
	/**
	 * minor allele frequency threshold
	 */
	private double maf;
	/**
	 * genome build
	 */
	private String genomeBuild;
	private MainWindow mainWindow;
	private boolean colorByFreq;
	/***
	 * Constructor
	 * @param clusters ArrayList of cluster objects
	 * @param population population to which the clusters are associated
	 * @param chromosome chromosome to which the clusters are associated
	 * @param conn connection parameters used for the analysis
	 * @param name architecture name
	 */
	public Architecture(ArrayList<Cluster> clusters,String dataset,String chromosome,MySQLConnection conn,
			String name,double maf,String genomeBuild,MainWindow mainWindow,boolean colorByMAF){
		this.clusters=clusters;
		this.dataset=dataset;
		this.chromosome=chromosome;
		this.conn=conn;
		this.name=name;
		this.maf=maf;
		this.genomeBuild=genomeBuild;
		this.mainWindow=mainWindow;
		this.colorByFreq=colorByMAF;
	}
	/***
	 * Build clusters at the chromosome level
	 * @param conn connection parameters used for the analysis
	 * @param chromosome chromosome for which to build clusters
	 * @param population population to which the clusters are associated
	 * @param includeSingletons if true SNPs not belonging to any cluster are included in the analysis
	 */
	public Architecture(MySQLConnection conn,String dataset,boolean includeSingletons,
			double maf,MainWindow mainWindow,boolean colorByMAF) throws SQLException{
		this.conn=conn;
		this.dataset=dataset;
		this.clusters=new ArrayList<Cluster>();
		this.name="region"+"-"+dataset+"-"+maf;
		this.maf=maf;
		this.mainWindow=mainWindow;
		this.colorByFreq=colorByMAF;
		Statement stmt;
		ResultSet rs;
		ArrayList<SNP> snps=new ArrayList<SNP>();
		try{
			stmt=this.conn.getConnection().createStatement();
			rs=stmt.executeQuery("SELECT rs FROM "+this.conn.getMapTable()+
				" WHERE maf>="+this.maf);
			while(rs.next()){
				String id=rs.getString("rs");
				SNP snp=new SNP(this.conn,id);
				this.chromosome=snp.getChromosome();
				snps.add(snp);
			}
			rs.close();
			stmt.close();
			for(SNP snp:snps){
				Cluster cluster=snp.getCluster(conn);
				if(!includeSingletons && cluster.getSNPs().size()==1)	// Do not include singletons
					continue;
				if(!this.clusters.contains(cluster))
					this.clusters.add(cluster);		
			}
		}catch(SQLException e){
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw e;
		}
	}
	/***
	 * Build clusters at the gene level
	 * @param conn connection parameters used for the analysis
	 * @param gene gene for which to build clusters
	 * @param kbp maximum distance from the TSS/TSE for a SNP to be included in the analysis
	 * @param population population to which the clusters are associated
	 * @param name name of the architecture
	 * @param includeSingletons if true SNPs not belonging to any cluster are included in the analysis
	 */
	public Architecture(MySQLConnection conn,Gene gene,int kbp,String dataset,String name,boolean includeSingletons,
			double maf,MainWindow mainWindow,boolean colorByMAF) throws SQLException{
		try{
			this.clusters=new ArrayList<Cluster>();
			this.dataset=dataset;
			this.conn=conn;
			this.name=name+"-"+dataset+"-"+maf;
			this.maf=maf;
			this.mainWindow=mainWindow;
			this.colorByFreq=colorByMAF;
			// Get info gene
			String chromosome=gene.getChromosome();
			this.chromosome=chromosome;
			// Get SNPs in the region
			ArrayList<SNP> snps=gene.getSNPs(this.conn, kbp,this.maf);
			// Get corresponding blocks and tagSNPs(unique)
			for(SNP snp:snps){
				Cluster cluster=snp.getCluster(conn);
				if(!includeSingletons && cluster.getSNPs().size()==1)	// Do not include singletons
					continue;
				if(!this.clusters.contains(cluster))
					this.clusters.add(cluster);		
			}
		}catch(SQLException e){
			throw e;
		}
	}
	/***
	 * Build clusters from a reference SNP
	 * @param conn connection parameters used for the analysis
	 * @param referenceSNP SNP for which the LD clusters must be computed
	 * @param population population to which the clusters are associated
	 * @param includeSingletons if true SNPs not belonging to any cluster are included in the analysis
	 * @param maf minor allele frequency threshold
	 */
	public Architecture(MySQLConnection conn,SNP referenceSNP,String dataset,boolean includeSingletons,
			double maf,MainWindow mainWindow,boolean colorByMAF) throws SQLException{
		try{
			this.clusters=new ArrayList<Cluster>();
			this.dataset=dataset;
			this.conn=conn;
			this.name=referenceSNP.getId()+"-"+dataset+"-"+maf;
			this.maf=maf;
			this.mainWindow=mainWindow;
			this.colorByFreq=colorByMAF;
			// Get info SNP
			String chromosome=referenceSNP.getChromosome();
			this.chromosome=chromosome;
			// Get SNPs in the region
			ArrayList<SNP> snps=referenceSNP.getSNPsInLD(this.conn,this.maf);
			for(SNP snp:snps){
				Cluster cluster=snp.getCluster(conn);
				if(!includeSingletons && cluster.getSNPs().size()==1){	// Do not include singletons
					if(cluster.getSNPs().get(0).equals(referenceSNP))
						this.clusters.add(cluster);
					continue;
				}
				if(!this.clusters.contains(cluster)){
					this.clusters.add(cluster);	
				}
			}	
		}catch(SQLException e){
			throw e;
		}
	}
	/**
	 * Prints an LD architecture as list of cluster, each cluster is printed on a different line
	 */
	public void print(){
		for(Cluster cluster:this.clusters){
			System.out.println(cluster);
		}
	}
	/**
	 * 
	 * @return list of clusters
	 */
	public ArrayList<Cluster> getClusters(){
		return this.clusters;
	}
	/**
	 * 
	 * @return population to which the clusters are associated
	 */
	public String getDataset(){
		return this.dataset;
	}
	/**
	 * 
	 * @return name of the architecture
	 */
	public String getName(){
		return this.name;
	}
	/**
	 * Export clusters in a UCSC bed track, each cluster is represented by a different track
	 * An additional track contains the SNP names
	 * This method is used to export architectures generated from a reference SNP
	 * @param filename track filename
	 * @param referenceSNPId reference SNP associated to the architecture
	 */
	public void exportUcscDistinctTracks(String filename,String referenceSNPId) throws SQLException{
		try{
			String idTrack=this.name.split("-")[0];
			SNP referenceSNP=new SNP(this.conn,referenceSNPId);
			HashMap<Double,ArrayList<Cluster>> ldMap=new HashMap<Double,ArrayList<Cluster>>();
			try{
				BufferedWriter file=new BufferedWriter(new FileWriter(filename));
				this.mainWindow.addFileToFilesCreated(filename);
				file.write("browser hide all\n");
				file.write("browser full refGene\n");
				file.write("track db='"+this.conn.getGenomeBuild()+"' name='"+idTrack+"-"+this.dataset+"-maf"+this.maf+"-SNPs' description=' ' itemRgb='On'\n");
				int globalMin=Integer.MAX_VALUE;
				int globalMax=0;
				// Write SNP names
				for(Cluster cluster:clusters){
					ArrayList<SNP> snps=cluster.getSNPs();
					for(SNP snp:snps){
						if(!SNP.exists(conn, snp.getId()))
							continue;
						int position=snp.getPosition();
						String id=snp.getId();
						file.write("chr"+this.chromosome+"\t"+(position-1)+"\t"+position+"\t"+id+"\t0\t+\t"+(position-1)+"\t"+position+"\t0,0,0\t");
						file.write("2"+"\t");
						file.write("1,1,\t");
						file.write("0,0,\n");
					}
				}
				// Get LD between clusters and referenceSNP
				for(Cluster cluster:clusters){
					SNP tagSNP=cluster.getTagSNP();
					double ld=referenceSNP.getLD(conn, tagSNP);
					if(ldMap.containsKey(ld)){
						ArrayList<Cluster> temp=ldMap.get(ld);
						temp.add(cluster);
						ldMap.put(ld, temp);
					}else{
						ArrayList<Cluster> temp=new ArrayList<Cluster>();
						temp.add(cluster);
						ldMap.put(ld, temp);
					}
				}
				// Order clusters according to keys
				ArrayList<Double> orderedKeys=new ArrayList<Double>();
				for(Double ld:ldMap.keySet()){
					orderedKeys.add(ld);
				}
				Collections.sort(orderedKeys);
				Collections.reverse(orderedKeys);
				for(Double key:orderedKeys){
					// Write clusters
					file.write("track db='"+this.conn.getGenomeBuild()+"' name='"+idTrack+"-"+this.dataset+"-maf"+this.maf+"-ld"+key+"' description=' ' itemRgb='On'\n");
					for(Cluster cluster:ldMap.get(key)){
						ArrayList<SNP> snps=cluster.getSNPs();
						int minPosition=Integer.MAX_VALUE;
						int maxPosition=0;
						ArrayList<Integer> positions=new ArrayList<Integer>();
						boolean empty=true;
						for(SNP snp:snps){
							if(!SNP.exists(conn, snp.getId()))
								continue;
							int position=snp.getPosition();
							positions.add(position);
							if(position<minPosition) minPosition=position;
							if(position>maxPosition) maxPosition=position;
							if(position<globalMin) globalMin=position;
							if(position>globalMax) globalMax=position;
							empty=false;
						}	
						if(!empty){
							Collections.sort(positions);
							file.write("chr"+this.chromosome+"\t"+(minPosition-1)+"\t"+maxPosition+"\t"+cluster.getTagSNP().getId()+"\t0\t+\t"+(minPosition-1)+"\t"+maxPosition+"\t"+this.getColorBasedOnFrequency(cluster.getTagSNP().getId())+"\t");
							if(positions.size()==1)
								file.write(positions.size()+1+"\t");
							else
								file.write(positions.size()+"\t");
							for(int k=0;k<positions.size();k++)
								file.write("1,");
							if(positions.size()==1)
								file.write("1,");
							file.write('\t');	
							for(int k=0;k<positions.size();k++)
								file.write(positions.get(k)-minPosition+",");
							if(positions.size()==1)
								file.write(positions.get(0)-minPosition+",");
							file.write("\n");
						}
					}
				}
				int span=(globalMax-globalMin)/10;
				int infBorder=globalMin-span;
				if(infBorder<0)
					infBorder=0;
				int supBorder=globalMax+span;
				file.write("browser position chr"+this.chromosome+":"+infBorder+"-"+supBorder+"\n");
				file.close();
			}catch(IOException e){
				e.printStackTrace();
			}
		}catch(SQLException e){
			throw e;
		}
	}
	/**
	 * Export clusters in a UCSC bed track, all clusters are merged in a single track
	 * An additional track contains the SNP names
	 * This method is used to export architectures generated for a gene or a chromosome
	 * @param filename track filename
	 */
	public void exportUcscMergedTracks(String filename) throws SQLException{
		String idTrack=this.name.split("-")[0];
		try{
			BufferedWriter file=new BufferedWriter(new FileWriter(filename));
			this.mainWindow.addFileToFilesCreated(filename);
			file.write("browser hide all\n");
			file.write("browser full refGene\n");
			file.write("track db='"+this.conn.getGenomeBuild()+"' name='"+idTrack+"-"+this.dataset+"-maf"+this.maf+"-SNPs' description=' ' itemRgb='On'\n");
			int globalMin=Integer.MAX_VALUE;
			int globalMax=0;
			for(Cluster cluster:clusters){
				ArrayList<SNP> snps=cluster.getSNPs();
				for(SNP snp:snps){
					if(!SNP.exists(conn, snp.getId()))
						continue;
					int position=snp.getPosition();
					String id=snp.getId();
					file.write("chr"+this.chromosome+"\t"+(position-1)+"\t"+position+"\t"+id+"\t0\t+\t"+(position-1)+"\t"+position+"\t0,0,0\t");
					file.write("2"+"\t");
					file.write("1,1,\t");
					file.write("0,0,\n");
				}
			}
			file.write("track db='"+this.conn.getGenomeBuild()+"' name='"+idTrack+"-"+this.dataset+"-maf"+this.maf+"-blocks"+"' description=' ' itemRgb='On' visibility=3\n");
			ArrayList<Cluster> singletons=new ArrayList<Cluster>();
			// Write clusters
			for(Cluster cluster:clusters){
				if(cluster.getSNPs().size()==1){
					singletons.add(cluster);
					continue;
				}
				ArrayList<SNP> snps=cluster.getSNPs();
				int minPosition=Integer.MAX_VALUE;
				int maxPosition=0;
				ArrayList<Integer> positions=new ArrayList<Integer>();
				boolean empty=true;
				for(SNP snp:snps){
					if(!SNP.exists(conn, snp.getId()))
						continue;
					int position=snp.getPosition();
					positions.add(position);
					if(position<minPosition) minPosition=position;
					if(position>maxPosition) maxPosition=position;
					if(position<globalMin) globalMin=position;
					if(position>globalMax) globalMax=position;
					empty=false;
				}	
				if(!empty){
					Collections.sort(positions);
					file.write("chr"+this.chromosome+"\t"+(minPosition-1)+"\t"+maxPosition+"\t"+cluster.getTagSNP().getId()+"\t0\t+\t"+(minPosition-1)+"\t"+maxPosition+"\t"+this.getColorBasedOnFrequency(cluster.getTagSNP().getId())+"\t");
					if(positions.size()==1)
						file.write(positions.size()+1+"\t");
					else
						file.write(positions.size()+"\t");
					for(int k=0;k<positions.size();k++)
						file.write("1,");
					if(positions.size()==1)
						file.write("1,");
					file.write('\t');	
					for(int k=0;k<positions.size();k++)
						file.write(positions.get(k)-minPosition+",");
					if(positions.size()==1)
						file.write(positions.get(0)-minPosition+",");
					file.write("\n");
				}
			}
			// Write singletons
			file.write("track db='"+this.conn.getGenomeBuild()+"' name='"+idTrack+"-"+this.dataset+"-maf"+this.maf+"-singletons"+"' description=' ' itemRgb='On'\n");
			for(Cluster cluster:singletons){
				ArrayList<SNP> snps=cluster.getSNPs();
				int minPosition=Integer.MAX_VALUE;
				int maxPosition=0;
				ArrayList<Integer> positions=new ArrayList<Integer>();
				boolean empty=true;
				for(SNP snp:snps){
					if(!SNP.exists(conn, snp.getId()))
						continue;
					int position=snp.getPosition();
					positions.add(position);
					if(position<minPosition) minPosition=position;
					if(position>maxPosition) maxPosition=position;
					if(position<globalMin) globalMin=position;
					if(position>globalMax) globalMax=position;
					empty=false;
				}	
				if(!empty){
					Collections.sort(positions);
					file.write("chr"+this.chromosome+"\t"+(minPosition-1)+"\t"+maxPosition+"\t"+cluster.getTagSNP().getId()+"\t0\t+\t"+(minPosition-1)+"\t"+maxPosition+"\t"+this.getColorBasedOnFrequency(cluster.getTagSNP().getId())+"\t");
					if(positions.size()==1)
						file.write(positions.size()+1+"\t");
					else
						file.write(positions.size()+"\t");
					for(int k=0;k<positions.size();k++)
						file.write("1,");
					if(positions.size()==1)
						file.write("1,");
					file.write('\t');	
					for(int k=0;k<positions.size();k++)
						file.write(positions.get(k)-minPosition+",");
					if(positions.size()==1)
						file.write(positions.get(0)-minPosition+",");
					file.write("\n");
				}
			}
			int span=(globalMax-globalMin)/10;
			int infBorder=globalMin-span;
			if(infBorder<0)
				infBorder=0;
			int supBorder=globalMax+span;
			file.write("browser position chr"+this.chromosome+":"+infBorder+"-"+supBorder+"\n");
			file.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	/**
	 * Export clusters in a UCSC bed track, each cluster is represented by a different track
	 * An additional track contains the SNP names
	 * This method is used to export architectures generated from an hierarchically ordered architecture
	 * @param filename track filename
	 */
	public void exportUcscDistinctTracks(String filename) throws SQLException{
		String idTrack=this.name.split("-")[0];
		try{
			BufferedWriter file=new BufferedWriter(new FileWriter(filename));
			this.mainWindow.addFileToFilesCreated(filename);
			file.write("browser hide all\n");
			file.write("browser full refGene\n");
			file.write("track db='"+this.conn.getGenomeBuild()+"' name='"+idTrack+"-"+this.dataset+"-maf"+this.maf+"-SNPs' description=' ' itemRgb='On'\n");
			int globalMin=Integer.MAX_VALUE;
			int globalMax=0;
			for(Cluster cluster:clusters){
				ArrayList<SNP> snps=cluster.getSNPs();
				for(SNP snp:snps){
					if(!SNP.exists(conn, snp.getId()))
						continue;
					int position=snp.getPosition();
					String id=snp.getId();
					file.write("chr"+this.chromosome+"\t"+(position-1)+"\t"+position+"\t"+id+"\t0\t+\t"+(position-1)+"\t"+position+"\t0,0,0\t");
					file.write("2"+"\t");
					file.write("1,1,\t");
					file.write("0,0,\n");
				}
			}
			// Write clusters
			for(Cluster cluster:clusters){
				file.write("track db='"+this.conn.getGenomeBuild()+"' name='"+idTrack+"-"+this.dataset+"-maf"+this.maf+"-"+cluster.getTagSNP().getId()+"' description=' ' itemRgb='On'\n");	
				ArrayList<SNP> snps=cluster.getSNPs();
				int minPosition=Integer.MAX_VALUE;
				int maxPosition=0;
				ArrayList<Integer> positions=new ArrayList<Integer>();
				boolean empty=true;
				for(SNP snp:snps){
					if(!SNP.exists(conn, snp.getId()))
						continue;
					int position=snp.getPosition();
					positions.add(position);
					if(position<minPosition) minPosition=position;
					if(position>maxPosition) maxPosition=position;
					if(position<globalMin) globalMin=position;
					if(position>globalMax) globalMax=position;
					empty=false;
				}	
				if(!empty){
					Collections.sort(positions);
					file.write("chr"+this.chromosome+"\t"+(minPosition-1)+"\t"+maxPosition+"\t"+cluster.getTagSNP().getId()+"\t0\t+\t"+(minPosition-1)+"\t"+maxPosition+"\t"+this.getColorBasedOnFrequency(cluster.getTagSNP().getId())+"\t");
					if(positions.size()==1)
						file.write(positions.size()+1+"\t");
					else
						file.write(positions.size()+"\t");
					for(int k=0;k<positions.size();k++)
						file.write("1,");
					if(positions.size()==1)
						file.write("1,");
					file.write('\t');	
					for(int k=0;k<positions.size();k++)
						file.write(positions.get(k)-minPosition+",");
					if(positions.size()==1)
						file.write(positions.get(0)-minPosition+",");
					file.write("\n");
				}
			}
			int span=(globalMax-globalMin)/10;
			int infBorder=globalMin-span;
			if(infBorder<0)
				infBorder=0;
			int supBorder=globalMax+span;
			file.write("browser position chr"+this.chromosome+":"+infBorder+"-"+supBorder+"\n");
			file.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	/**
	 * Cluster an architecture hierarchically, a plot of the clustering is generated using R and is stored in 
	 * the working dir
	 * @param id suffix to use for the temporary files
	 * @return a hierarchically clustered architecture
	 * @throws OrderedSNPsLDFileNotFound 
	 */
	public Architecture cluster(String id) throws SQLException,TooManySNPsException,NotEnoughClustersToBuildHierarchicalTree,
	ExecutableNotFoundException, OrderedSNPsLDFileNotFound{
		if(this.clusters.size()>this.conn.getMaxNumberElementsToCluster())
			throw new TooManySNPsException();
		if(this.clusters.size()<2)
			throw new NotEnoughClustersToBuildHierarchicalTree();
		try{
			Architecture orderedArchitecture=new Architecture(new ArrayList<Cluster>(this.clusters),
					this.dataset,this.chromosome,this.conn,this.name+".ordered",this.maf,this.genomeBuild,
					this.mainWindow,this.colorByFreq);
			String LD_matrix=this.conn.getWorkingDir()+id+".ld.matrix.txt";
			this.createLDMatrix(LD_matrix);
			String image_filename=this.conn.getWorkingDir()+id+".ordered.ld.png";
			String ordered_snps_filename=this.conn.getWorkingDir()+id+".ordered.snps.ld.txt";
			int height=23*this.clusters.size()+20;
			InputStream jarR = getClass().getResourceAsStream("/core_server/hierarchicalClusteringScript.R");
			InputStreamReader isr = new InputStreamReader(jarR);
			BufferedReader file=new BufferedReader(isr);
			String currentLine;
			String extractedScriptFilename = this.conn.getWorkingDir()+"hierarchicalClusteringScript.R";
			try {
				BufferedWriter writer=new BufferedWriter(new FileWriter(extractedScriptFilename));
				this.mainWindow.addFileToFilesCreated(extractedScriptFilename);
				while((currentLine =file.readLine()) != null)
					writer.write(currentLine+"\n");
				writer.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			String[] cmd=new String[]{conn.getRPath(),"CMD","BATCH",
					"--args "+LD_matrix+" "+
					image_filename+" " +
					+300+" "+
					height+" "+
					ordered_snps_filename,
					extractedScriptFilename,
					this.conn.getWorkingDir()+id+"Routput.txt"};
			Runtime runtime = Runtime.getRuntime();
		    try {
				Process process = runtime.exec(cmd);
				process.waitFor();
			} catch (IOException e) {
				e.printStackTrace();
				throw new ExecutableNotFoundException();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			orderedArchitecture.orderClusters(ordered_snps_filename);
			this.mainWindow.addFileToFilesCreated(image_filename);
			this.mainWindow.addFileToFilesCreated(ordered_snps_filename);
			this.mainWindow.addFileToFilesCreated(this.conn.getWorkingDir()+id+"Routput.txt");
			return orderedArchitecture;
		}catch(SQLException e){
			throw e;
		}
	}
	/**
	 * Creates an LD matrix containing pairwise LD information between all the tag SNPs of the clusters belonging
	 * to the architecture
	 * @param filename LD matrix filename
	 */
	private void createLDMatrix(String filename) throws SQLException{
		Statement stmt;
		ResultSet rs;
		try {
			BufferedWriter writer=new BufferedWriter(new FileWriter(filename));
			this.mainWindow.addFileToFilesCreated(filename);
			// Write header
			writer.write("SNPs");
			for(Cluster cluster:this.clusters)
				writer.write("\t"+cluster.getTagSNP().getId());
			writer.write("\n");
			// Write body
			for(Cluster cluster1:this.clusters){
				writer.write(cluster1.getTagSNP().getId());
				for(Cluster cluster2:this.clusters){
					try{
						stmt=this.conn.getConnection().createStatement();
						String cmd="SELECT rsquared FROM "+this.conn.getLdTable()+
						" WHERE (rs1='"+cluster1.getTagSNP().getId()+"' AND rs2='"+cluster2.getTagSNP().getId()+
						"') OR (rs1='"+cluster2.getTagSNP().getId()+"' AND rs2='"+cluster1.getTagSNP().getId()+"')";
						rs=stmt.executeQuery(cmd);
						if (!rs.isBeforeFirst()){    
							double rsquared=1;
							writer.write("\t"+rsquared);
							writer.flush();
						}
						while(rs.next()){
							double rsquared=rs.getDouble("rsquared");
							writer.write("\t"+rsquared);
							writer.flush();
						}
						rs.close();
						stmt.close();
					}catch(SQLException e){
						e.printStackTrace();
						System.out.println("SQLException: " + e.getMessage());
						System.out.println("SQLState: " + e.getSQLState());
						throw e;
					}
				}
				writer.write("\n");
			}
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/***
	 * Order clusters based on a filename containing a list of SNPs, one SNP per line
	 * @param filename file produced by the R script containing the name of the SNPs in the order dictated by the hierarchical clustering
	 */
	private void orderClusters(String filename) throws OrderedSNPsLDFileNotFound{
		ArrayList<String> tagSNPs=new ArrayList<String>();
		try {
			BufferedReader reader=new BufferedReader(new FileReader(filename));
			String line;
			while((line=reader.readLine())!=null){
				tagSNPs.add(line);
			}
			this.orderClusters(tagSNPs);
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new OrderedSNPsLDFileNotFound();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Order clusters based on a list of tag SNPs
	 * @param tagSNPs list of tag SNPs
	 */
	private void orderClusters(ArrayList<String> tagSNPs){
		ArrayList<Cluster> orderedClusters=new ArrayList<Cluster>();
		for(String tagSNPId:tagSNPs)
			for(Cluster cluster:this.clusters)
				if(cluster.getTagSNP().getId().compareTo(tagSNPId)==0)
					orderedClusters.add(cluster);
		this.clusters=orderedClusters;
	}
	public void exportToXml(String filename){
		try {
			DocumentBuilderFactory docFactory= DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = docFactory.newDocumentBuilder();
			Document document=builder.newDocument();
			Element root=document.createElement("architecture");
			document.appendChild(root);
			for(Cluster cluster:this.clusters){
				Element c=document.createElement("cluster");
				Attr attr = document.createAttribute("tagSNP");
				attr.setValue(cluster.getTagSNP().getId());
				c.setAttributeNode(attr);
				for(SNP snp:cluster.getSNPs()){
					Element s=document.createElement("SNP");
					s.appendChild(document.createTextNode(snp.getId()));
					c.appendChild(s);
				}
				root.appendChild(c);
				TransformerFactory transformerFactory=TransformerFactory.newInstance();
				Transformer transformer=transformerFactory.newTransformer();
				DOMSource domSource=new DOMSource(document);
				StreamResult streamResult=new StreamResult(new File(filename));
				transformer.transform(domSource, streamResult);
			}
			this.mainWindow.addFileToFilesCreated(filename);
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Create export SNP list
	 */
	public void exportSNPs(String filename){
		try{
			BufferedWriter writer=new BufferedWriter(new FileWriter(filename));
			for(Cluster cluster:this.getClusters()){
				//for(SNP snp:cluster.getSNPs()){
				//	writer.write(snp.getId()+"\n");
				//}
				if(cluster.getSNPs().size()>2)
					writer.write(cluster.getTagSNP().getId()+"\n");
			}
			writer.close();	
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	/**
	 * Create genotype file for Haploview
	 */
	public void createGenotypeFileForHaploview(String genoFilename,String snpListFilename,String prefix){
		String[] cmd=new String[]{"plink","--noweb","--bfile",genoFilename,"--extract",snpListFilename,
				"--recode","--output-missing-phenotype","0","--out",prefix};
		Runtime runtime = Runtime.getRuntime();
	    try {
			Process process = runtime.exec(cmd);
			process.waitFor();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	    // Modify map file to fit Haploview requirements
	    try{
	    	String mapFilename=prefix+".map";
	    	String infoFilename=prefix+".info";
	    	BufferedReader reader=new BufferedReader(new FileReader(mapFilename));
			BufferedWriter writer=new BufferedWriter(new FileWriter(infoFilename));
			String currentLine;
			while ((currentLine = reader.readLine()) != null) {
				String[] elements=currentLine.split("\t");
				writer.write(elements[1]+"\t");
				writer.write(elements[3]+"\n");
			}
			writer.close();	
			reader.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	/**
	 * Build haplotypes using Haploview
	 */
	public void buildHaplotypeFile(String pedFilename,String infoFilename,String haploPrefix,String logFilename){
		//String[] cmd=new String[]{"java","-jar","C:/Progra~1/Haploview.jar","-nogui","-pedfile",pedFilename,
		//		"-info",infoFilename,"-blockoutput","GAB","-blockCutLowCI","0",
		//		"-blockInformFrac","0","-hapthresh","0.008","-out",haploPrefix};
		String[] cmd=new String[]{"java","-jar","C:/Progra~1/Haploview.jar","-nogui","-pedfile",pedFilename,
				"-info",infoFilename,"-blockoutput","SPI","-blockSpineDP","0",
				"-hapthresh","0.008","-out",haploPrefix};
		System.out.print("\n");
		Runtime runtime = Runtime.getRuntime();
	    try {
			Process process = runtime.exec(cmd);
			process.waitFor();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<Haplotype> buildHaplotypes(String haploFilename,String infoFilename){
		ArrayList<Haplotype> haplotypes=new ArrayList<Haplotype>();
	    // Build haplotypes from file
		BufferedReader reader;
		ArrayList<SNP> snps=new ArrayList<SNP>();
		try {
			System.out.println("Getting markers");
			String currentLine;
			reader = new BufferedReader(new FileReader(infoFilename));
			while ((currentLine = reader.readLine()) != null) {
				String[] elements=currentLine.split("\t");
				String snpId=elements[0];
				SNP snp=new SNP(this.conn,snpId);
				snps.add(snp);
			}
			reader.close();
			System.out.println("Computing haplotypes");
			//reader = new BufferedReader(new FileReader(haploFilename+".GABRIELblocks"));
			reader = new BufferedReader(new FileReader(haploFilename+".SPINEblocks"));
			boolean header=true;
			int counter=0;
			while ((currentLine = reader.readLine()) != null) {
				String[] elements=currentLine.split(" ");
				if(header==true){	// Skip header
					header=false;
					continue;
				}
				String stringAlleles=elements[0];
				String freqStr=elements[1].substring(1,elements[1].length()-1);
				double freq=Double.parseDouble(freqStr);
				Haplotype haplo=new Haplotype(stringAlleles,snps,freq,"h"+counter);
				haplotypes.add(haplo);
				counter=counter+1;
			}
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return haplotypes;
	}
	
	/**
	 * Return chimp haplotype
	 */
	public Haplotype getAncestorHaplotype(String ancestor){
		ArrayList<SNP> snps=new ArrayList<SNP>();
		for(Cluster cluster:this.getClusters())
			snps.add(cluster.getTagSNP());
		Haplotype chimp=new Haplotype(this.conn,snps,ancestor,"h"+ancestor);
		return chimp;
	}
	
	private String getColorBasedOnFrequency(String rsid) throws SQLException{
		String color="0,0,0";
		if(this.colorByFreq==false)
			return color;
		Statement stmt;
		ResultSet rs;
		try {
			stmt=this.conn.getConnection().createStatement();
			String cmd="SELECT maf FROM "+this.conn.getMapTable()+" WHERE rs='"+rsid+"'";
			rs=stmt.executeQuery(cmd);
			while(rs.next()){
					Double maf=rs.getDouble("maf");
					if(maf<0.05)
						color="0,255,0";
					else if(maf<0.1)
						color="113,255,0";
					else if(maf<0.15)
						color="226,255,0";
					else if(maf<0.2)
						color="255,170,0";
					else if(maf<0.25)
						color="255,56,0";
					else if(maf<0.3)
						color="255,0,56";
					else if(maf<0.35)
						color="255,0,170";
					else if(maf<0.4)
						color="226,0,255";
					else if(maf<0.45)
						color="113,0,255";
					else
						color="0,0,255";
			}
			rs.close();
			stmt.close();
			return color;
		} catch (SQLException e) {
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw e;
		}
	}
}