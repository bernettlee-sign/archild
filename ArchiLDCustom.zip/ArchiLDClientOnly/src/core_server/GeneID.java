/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package core_server;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class GeneID {
	/**
	 * format used for the ID {entrez_geneid,genbank_accession,mrna_accession,protein_accession,swissprot_accession,swissprot_id,symbol}
	 */
	String format;
	/**
	 * ID
	 */
	String name;
	/**
	 * Constructs an ID object
	 * @param format format of the ID {entrez_geneid,genbank_accession,mrna_accession,protein_accession,swissprot_accession,swissprot_id,symbol}
	 * @param name ID
	 */
	public GeneID(String format,String name){
		this.format=format;
		this.name=name;
	}
	/**
	 * Compares two IDs
	 * @param gid gene id
	 * @return true if the two IDs have the same format and the same ID
	 */
	public boolean equalTo(GeneID gid){
		if(gid.format==this.format && gid.name==this.name)
			return true;
		else
			return false;
		
	}
	/**
	 * Returns the format of the object
	 * @return format of the object
	 */
	public String getFormat(){
		return this.format;
	}
	/**
	 * Returns the ID of the object
	 * @return ID of the object
	 */
	public String getName(){
		return this.name;
	}
}
