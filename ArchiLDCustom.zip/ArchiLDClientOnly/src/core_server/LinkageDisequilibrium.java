/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package core_server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import exceptions.ConnectionLostException;
import exceptions.LinkageDisequilibriumException;
import gui.MainWindow;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class LinkageDisequilibrium {
	private MySQLConnection conn;
	private MainWindow mainWindow;
	
	public LinkageDisequilibrium(MySQLConnection conn,MainWindow mainWindow){
		this.conn=conn;
		this.mainWindow=mainWindow;
	}
	
	public boolean isFreqFileCompatible(String freqFilename){
		boolean isCompatible=true;
		try {
			BufferedReader freqReader=new BufferedReader(new FileReader(freqFilename));
			String currentLine;
			boolean header=true;
			while((currentLine=freqReader.readLine())!=null){
				if(header==true){
					header=false;
					continue;
				}
				String[] elements=currentLine.trim().split("\\s+");
				if(elements.length!=6){
					return false;
				}
				// Check if the fifth column can be parsed into a double
				try{
					double maf=Double.parseDouble(elements[4]);
				}catch(NumberFormatException e){
					return false;
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}		
		return isCompatible;
	}
	
	public boolean isInfoFileCompatible(String infoFilename){
		boolean isCompatible=true;
		try {
			BufferedReader freqReader=new BufferedReader(new FileReader(infoFilename));
			String currentLine;
			while((currentLine=freqReader.readLine())!=null){
				String[] elements=currentLine.trim().split("\\s+");
				if(elements.length!=2){
					return false;
				}
				// Check if the second column can be parsed into an int
				try{
					double maf=Double.parseDouble(elements[1]);
				}catch(NumberFormatException e){
					return false;
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}		
		return isCompatible;
	}
	
	public boolean isLDFileCompatible(String ldFilename){
		boolean isCompatible=true;
		try {
			BufferedReader freqReader=new BufferedReader(new FileReader(ldFilename));
			String currentLine;
			boolean header=true;
			while((currentLine=freqReader.readLine())!=null){
				if(header==true){
					header=false;
					continue;
				}
				String[] elements=currentLine.trim().split("\\s+");
				if(elements.length!=9){
					return false;
				}
				// Check if the fifth column can be parsed into an int
				try{
					double rsquared=Double.parseDouble(elements[4]);
				}catch(NumberFormatException e){
					return false;
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}		
		return isCompatible;
	}
	
	public void computeLD(String HaplotypePath,String pedFilename,String infoFilename,
			String haploviewFilename,String workingDir) throws LinkageDisequilibriumException{
		String tempString=new String(haploviewFilename);
		String nameFile=tempString.substring(tempString.lastIndexOf("/")+1,tempString.lastIndexOf(".LD"));
		String filenamePrefix=workingDir+nameFile;
		//String filenamePrefix=tempString.substring(0,tempString.lastIndexOf(".LD"));
		String[] cmd=new String[]{"java","-jar",HaplotypePath,"-nogui","-pedfile",pedFilename,
				"-info",infoFilename,"-dprime","-out",filenamePrefix};
		this.mainWindow.addFileToFilesCreated(filenamePrefix+".LD");
		System.out.print("\n");
		Runtime runtime = Runtime.getRuntime();
	    try {
			Process process = runtime.exec(cmd);
			process.waitFor();
		} catch (IOException e) {
			e.printStackTrace();
			throw new LinkageDisequilibriumException(e.getMessage());
		} catch (InterruptedException e) {
			e.printStackTrace();
			throw new LinkageDisequilibriumException(e.getMessage());
		}
	}
	
	public void uploadToMySQL(String prefix,String haploviewFilename,String chromosome,
			String infoFilename,String genomeBuild,String freqFilename,String workingDir) throws LinkageDisequilibriumException{
		String tempString=new String(haploviewFilename);
		String nameFile=tempString.substring(tempString.lastIndexOf("/")+1,tempString.lastIndexOf(".LD"));
		String filenamePrefix=workingDir+nameFile;
		//String filenamePrefix=tempString.substring(0,tempString.lastIndexOf(".LD"));
		String blocksFilename=workingDir+prefix+".info.blocks";
		String snpsBlocksFilename=workingDir+prefix+".snps.blocks";
		String ldCompleteFilename=workingDir+prefix+".complete.ld";
		String ldFilename=workingDir+prefix+".allpairs.ld";
		String mapFilename=workingDir+prefix+".map";
		HashMap<String,Integer> dictBlocks=new HashMap<String,Integer>();
		HashMap<Integer,ArrayList<String>> dictTagSNPs=new HashMap<Integer,ArrayList<String>>();
		int blockNumber=0;
		HashSet tagSNPs=new HashSet();
		try {
			BufferedReader reader=new BufferedReader(new FileReader(haploviewFilename));
			BufferedWriter blocksWriter=new BufferedWriter(new FileWriter(blocksFilename));
			this.mainWindow.addFileToFilesCreated(blocksFilename);
			BufferedWriter snpsBlocksWriter=new BufferedWriter(new FileWriter(snpsBlocksFilename));
			this.mainWindow.addFileToFilesCreated(snpsBlocksFilename);
			String currentLine;
			boolean header=true;
			while((currentLine=reader.readLine())!=null){
				if(header==true){
					header=false;
					continue;
				}
				String[] elements=currentLine.split("\t");
				String snp1=elements[0];
				String snp2=elements[1];
				double rsquared=Double.parseDouble(elements[4]);
				boolean block1Found=false;
				boolean block2Found=false;
				int block1=0;
				int block2=0;
				String tagSNP;
				int numSNPs=1;
				if(rsquared==1){
					if(dictBlocks.containsKey(snp1)){
						block1Found=true;
						block1=dictBlocks.get(snp1);
					}
					if(dictBlocks.containsKey(snp2)){
						block2Found=true;
						block2=dictBlocks.get(snp2);
					}
					if(block1Found && block2Found){
						if(block1!=block2)
							System.out.println("Error");
					}else{
						if(block1Found){
							dictBlocks.put(snp2, block1);
							ArrayList<String> temp=dictTagSNPs.get(block1);
							tagSNP=temp.get(0);
							numSNPs=Integer.parseInt(temp.get(1));
							numSNPs++;
							temp.set(0,tagSNP);
							temp.set(1,String.valueOf(numSNPs));
							dictTagSNPs.put(block1, temp);
						}else{
							if(block2Found){
								dictBlocks.put(snp1, block2);
								ArrayList<String> temp=dictTagSNPs.get(block2);
								tagSNP=temp.get(0);
								numSNPs=Integer.parseInt(temp.get(1));
								numSNPs++;
								temp.set(0,tagSNP);
								temp.set(1,String.valueOf(numSNPs));
								dictTagSNPs.put(block2, temp);
							}else{
								int block=blockNumber;
								dictBlocks.put(snp1, blockNumber);
								dictBlocks.put(snp2, blockNumber);
								if(dictTagSNPs.containsKey(block)){
									ArrayList<String> temp=dictTagSNPs.get(block);
									tagSNP=temp.get(0);
									numSNPs=Integer.parseInt(temp.get(1));
									numSNPs++;
									temp.set(0,tagSNP);
									temp.set(1,String.valueOf(numSNPs));
									dictTagSNPs.put(block, temp);
								}else{
									ArrayList<String> temp=new ArrayList<String>();
									tagSNP=snp1;
									numSNPs++;
									temp.add(tagSNP);
									temp.add(String.valueOf(numSNPs));
									dictTagSNPs.put(blockNumber, temp);
									tagSNPs.add(tagSNP);
								}
								blockNumber++;
							}
						}
					}			
				}
			}
			for(String snp:dictBlocks.keySet())
				snpsBlocksWriter.write(snp+"\t"+dictBlocks.get(snp)+"\t"+chromosome+"\n");
			for(Integer block:dictTagSNPs.keySet())
				blocksWriter.write(block+"\t"+dictTagSNPs.get(block).get(0)+"\t"+dictTagSNPs.get(block).get(1)+"\t"+chromosome+"\n");
			reader.close();
			blocksWriter.close();
			snpsBlocksWriter.close();	
			
			String blocksTableName=prefix+"_complete_blocks";
			this.createTableBlocks(blocksTableName,blocksFilename);
			String snpsBlocksTableName=prefix+"_complete_snps_blocks";
			this.createTableSNPsBlocks(snpsBlocksTableName, snpsBlocksFilename);
			
			// Generate LD files and LD tables
			reader=new BufferedReader(new FileReader(haploviewFilename));
			BufferedWriter ldWriterComplete=new BufferedWriter(new FileWriter(ldCompleteFilename));
			this.mainWindow.addFileToFilesCreated(ldCompleteFilename);
			BufferedWriter ldWriter=new BufferedWriter(new FileWriter(ldFilename));
			this.mainWindow.addFileToFilesCreated(ldFilename);
			header=true;
			while((currentLine=reader.readLine())!=null){
				if(header==true){
					header=false;
					continue;
				}
				String[] elements=currentLine.split("\t");
				String snp1=elements[0];
				String snp2=elements[1];
				double rsquared=Double.parseDouble(elements[4]);
				if(tagSNPs.contains(snp1) && tagSNPs.contains(snp2))
					ldWriterComplete.write(currentLine+"\n");
				if(rsquared>=0.5){
					ldWriter.write(currentLine+"\n");
				}
			}
			ldWriter.close();
			ldWriterComplete.close();
			reader.close();
			
			String ldCompleteTableName=prefix+"_complete_ld";
			this.createTableLD(ldCompleteTableName,ldCompleteFilename);
			String ldTableName=prefix+"_ld";
			this.createTableLD(ldTableName, ldFilename);
			
			// Generate freq map
			HashMap<String,Double> freqMap=new HashMap<String,Double>();
			BufferedReader freqReader=new BufferedReader(new FileReader(freqFilename));
			header=true;
			while((currentLine=freqReader.readLine())!=null){
				currentLine=currentLine.trim();
				String[] elements=currentLine.substring(0,currentLine.length()-2).split("[ ]+");
				if(header==true){
					header=false;
					continue;
				}
				String snp=elements[1];
				double maf=Double.parseDouble(elements[4]);
				freqMap.put(snp, maf);
			}
						
			// Generate map file
			BufferedReader infoReader=new BufferedReader(new FileReader(infoFilename));
			BufferedWriter mapWriter=new BufferedWriter(new FileWriter(mapFilename));
			this.mainWindow.addFileToFilesCreated(mapFilename);
			while((currentLine=infoReader.readLine())!=null){
				String[] elements=currentLine.split("\t");
				String rs=elements[0];
				int position=Integer.parseInt(elements[1]);
				mapWriter.write(chromosome+"\t"+rs+"\t"+position+"\t"+freqMap.get(rs)+"\n");
			}
			mapWriter.close();
			infoReader.close();
			
			String mapTableName=prefix+"_complete_map";
			this.createTableMap(mapTableName, mapFilename);
			
			this.addDatasetToList(prefix,genomeBuild);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			String msg="Problem creating the LD file to load in the database. Please check that Haploview is installed correctly" +
					" and that the path to the executable is correct.";
			throw new LinkageDisequilibriumException(msg);
		} catch (IOException e) {
			e.printStackTrace();
			throw new LinkageDisequilibriumException(e.getMessage());
		}
	}
	
	private void createTableBlocks(String tableName,String dataFilename) throws LinkageDisequilibriumException{
		Statement stmt;
		if(!this.doesTableExists(tableName)){
			try{
				stmt=this.conn.getConnection().createStatement();
				stmt.executeUpdate("CREATE TABLE "+tableName+"(block int,tag_snp varchar(50)," +
						"num_snps int,chr varchar(30))");
				stmt.close();
			}catch(SQLException e){
				e.printStackTrace();
			    System.out.println("SQLException: " + e.getMessage());
			    System.out.println("SQLState: " + e.getSQLState());
			    throw new LinkageDisequilibriumException(e.getMessage());
			}
		}
		try{
			stmt=this.conn.getConnection().createStatement();
			stmt.executeUpdate("LOAD DATA LOCAL INFILE '"+dataFilename+"' INTO TABLE "+tableName);
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw new LinkageDisequilibriumException(e.getMessage());
		}
	}
	
	private void createTableSNPsBlocks(String tableName,String dataFilename) throws LinkageDisequilibriumException{
		Statement stmt;
		if(!this.doesTableExists(tableName)){
			try{
				stmt=this.conn.getConnection().createStatement();
				stmt.executeUpdate("CREATE TABLE "+tableName+"(rs varchar(50),block int," +
						"chr varchar(30))");
				stmt.close();
			}catch(SQLException e){
				e.printStackTrace();
			    System.out.println("SQLException: " + e.getMessage());
			    System.out.println("SQLState: " + e.getSQLState());
			    throw new LinkageDisequilibriumException(e.getMessage());
			}
		}
		try{
			stmt=this.conn.getConnection().createStatement();
			stmt.executeUpdate("LOAD DATA LOCAL INFILE '"+dataFilename+"' INTO TABLE "+tableName);
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw new LinkageDisequilibriumException(e.getMessage());
		}
	}
	
	private void createTableMap(String tableName,String dataFilename) throws LinkageDisequilibriumException{
		Statement stmt;
		if(!this.doesTableExists(tableName)){
			try{
				stmt=this.conn.getConnection().createStatement();
				stmt.executeUpdate("CREATE TABLE "+tableName+"(chr varchar(30),rs varchar(50)," +
						"position int,maf double)");
				stmt.close();
			}catch(SQLException e){
				e.printStackTrace();
			    System.out.println("SQLException: " + e.getMessage());
			    System.out.println("SQLState: " + e.getSQLState());
			    throw new LinkageDisequilibriumException(e.getMessage());
			}
		}
		try{
			stmt=this.conn.getConnection().createStatement();
			stmt.executeUpdate("LOAD DATA LOCAL INFILE '"+dataFilename+"' INTO TABLE "+tableName);
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw new LinkageDisequilibriumException(e.getMessage());
		}
	}
	
	private void createTableLD(String tableName,String dataFilename) throws LinkageDisequilibriumException{
		Statement stmt;
		if(!this.doesTableExists(tableName)){
			try{
				stmt=this.conn.getConnection().createStatement();
				stmt.executeUpdate("CREATE TABLE "+tableName+"(rs1 varchar(50),rs2 varchar(50)," +
						"dprime double,lod double,rsquared double,CIlow double,CIhi double," +
						"dist int,Tint double)");
				stmt.close();
			}catch(SQLException e){
				e.printStackTrace();
			    System.out.println("SQLException: " + e.getMessage());
			    System.out.println("SQLState: " + e.getSQLState());
			    throw new LinkageDisequilibriumException(e.getMessage());
			}
		}
		try{
			stmt=this.conn.getConnection().createStatement();
			stmt.executeUpdate("LOAD DATA LOCAL INFILE '"+dataFilename+"' INTO TABLE "+tableName);
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw new LinkageDisequilibriumException(e.getMessage());
		}
	}
	
	private void addDatasetToList(String prefix,String genomeBuild) throws LinkageDisequilibriumException{
		Statement stmt;
		if(!this.doesTableExists("datasets")){
			try{
				stmt=this.conn.getConnection().createStatement();
				stmt.executeUpdate("CREATE TABLE datasets(prefix varchar(250),genome_build varchar(4))");
				stmt.close();
			}catch(SQLException e){
				e.printStackTrace();
			    System.out.println("SQLException: " + e.getMessage());
			    System.out.println("SQLState: " + e.getSQLState());
			    throw new LinkageDisequilibriumException(e.getMessage());
			}
		}
		try{
			stmt=this.conn.getConnection().createStatement();
			ResultSet rs=stmt.executeQuery("SELECT * FROM datasets WHERE prefix='"+prefix+"'");
			boolean exists=true;
			if(!rs.isBeforeFirst())
				exists=false;
			rs.close();
			stmt.close();
			stmt=this.conn.getConnection().createStatement();
			if(exists==false);
				stmt.executeUpdate("INSERT INTO datasets VALUES('"+prefix+"','"+genomeBuild+"')");						
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw new LinkageDisequilibriumException(e.getMessage());
		}
	}
	
	public boolean doesTableExists(String tableName) throws LinkageDisequilibriumException{
		Statement stmt;
		ResultSet rs;
		try{
			stmt=this.conn.getConnection().createStatement();
			rs=stmt.executeQuery("SELECT table_name FROM information_schema.tables WHERE table_schema='"+
					this.conn.getDatabase()+"' AND table_name='"+tableName+"'");
			if(!rs.isBeforeFirst())
				return false;
			rs.close();
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw new LinkageDisequilibriumException(e.getMessage());
		}
		return true;
	}
	
	public boolean existsFilesSameName(String filenamePrefix){
		boolean exists=false;
		String filename=filenamePrefix+".LD";
		File f=new File(filename);
		if(f.exists())
			exists=true;
		
		String blocksFilename=filenamePrefix+".info.blocks";
		f=new File(blocksFilename);
		if(f.exists())
			exists=true;
		
		String snpsBlocksFilename=filenamePrefix+".snps.blocks";
		f=new File(snpsBlocksFilename);
		if(f.exists())
			exists=true;
		
		String ldCompleteFilename=filenamePrefix+".complete.ld";
		f=new File(ldCompleteFilename);
		if(f.exists())
			exists=true;
		
		String ldFilename=filenamePrefix+".ld";
		f=new File(ldFilename);
		if(f.exists())
			exists=true;
		
		String mapFilename=filenamePrefix+".map";
		f=new File(mapFilename);
		if(f.exists())
			exists=true;
		return exists;
	}
	
	public boolean existsDatasetSameName(String prefix) throws LinkageDisequilibriumException{
		Statement stmt;
		ResultSet rs;
		if(!this.doesTableExists("datasets")){
			return false;
		}
		else{
			try{
				stmt=this.conn.getConnection().createStatement();
				rs=stmt.executeQuery("SELECT prefix FROM datasets WHERE prefix='"+prefix+"'");
				if(!rs.isBeforeFirst())
					return false;
				rs.close();
				stmt.close();
			}catch(SQLException e){
				e.printStackTrace();
			    System.out.println("SQLException: " + e.getMessage());
			    System.out.println("SQLState: " + e.getSQLState());
			}
			return true;
		}
	}
	
	public void deleteDataset(String prefix) throws ConnectionLostException{
		Statement stmt;
		try{
			stmt=this.conn.getConnection().createStatement();
			stmt.executeUpdate("DELETE FROM datasets WHERE prefix='"+prefix+"'");
			stmt.close();
			
			stmt=this.conn.getConnection().createStatement();
			stmt.executeUpdate("DROP TABLE "+prefix+"_complete_ld");
			stmt.close();
			
			stmt=this.conn.getConnection().createStatement();
			stmt.executeUpdate("DROP TABLE "+prefix+"_complete_map");
			stmt.close();
			
			stmt=this.conn.getConnection().createStatement();
			stmt.executeUpdate("DROP TABLE "+prefix+"_complete_blocks");
			stmt.close();
			
			stmt=this.conn.getConnection().createStatement();
			stmt.executeUpdate("DROP TABLE "+prefix+"_complete_snps_blocks");
			stmt.close();
			
			stmt=this.conn.getConnection().createStatement();
			stmt.executeUpdate("DROP TABLE "+prefix+"_ld");
			stmt.close();
			
		}catch(SQLException e){
			throw new ConnectionLostException(e);
		}
	}
}
