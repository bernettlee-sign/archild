/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package gui;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.trolltech.qt.core.QThreadPool;
import com.trolltech.qt.core.Qt;
import com.trolltech.qt.gui.QApplication;
import com.trolltech.qt.gui.QComboBox;
import com.trolltech.qt.gui.QDialog;
import com.trolltech.qt.gui.QFileDialog;
import com.trolltech.qt.gui.QGroupBox;
import com.trolltech.qt.gui.QHBoxLayout;
import com.trolltech.qt.gui.QLabel;
import com.trolltech.qt.gui.QLineEdit;
import com.trolltech.qt.gui.QMessageBox;
import com.trolltech.qt.gui.QProgressBar;
import com.trolltech.qt.gui.QMessageBox.StandardButtons;
import com.trolltech.qt.gui.QPushButton;
import com.trolltech.qt.gui.QVBoxLayout;
import com.trolltech.qt.gui.QDialogButtonBox.StandardButton;

import core.ProcessingThreadArchitecture;
import core.ProcessingThreadLinkage;
import core.RequestKey;
import core_server.LinkageDisequilibrium;
import exceptions.EmptyFieldException;
import exceptions.LinkageDisequilibriumException;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class LoadDatasetWindow extends QDialog{
	private QLineEdit pedTextBox;
	private QLineEdit infoTextBox;
	private QLineEdit freqTextBox;
	private QLineEdit prefixTextBox;
	private QLineEdit haploviewLDTextBox;
	private QComboBox inputTypeTextBox;
	private QComboBox chrTextBox;
	private QComboBox genomeBuildComboBox;
	private QGroupBox linkageFormatGroupBox;
	private QGroupBox haploviewFormatGroupBox;
	private QGroupBox optionsGroupBox;
	private MainWindow mainWindow;
	private LinkageDisequilibrium ld;
	private ProcessingThreadLinkage processingThread;
	QDialog progressBarDialog;
	private boolean error;
	
	public LoadDatasetWindow(MainWindow mainWindow){
		this.error=false;
		this.mainWindow=mainWindow;
		this.ld=new LinkageDisequilibrium(this.mainWindow.getServer().getMySQLConnection(),mainWindow);
		this.setWindowTitle("Load dataset");
		QVBoxLayout mainLayout=new QVBoxLayout();
		QVBoxLayout linkageFormatLayout=new QVBoxLayout();
		QVBoxLayout haploviewFormatLayout=new QVBoxLayout();
		QVBoxLayout optionsLayout=new QVBoxLayout();
		
		this.linkageFormatGroupBox=new QGroupBox("Linkage format");
		this.haploviewFormatGroupBox=new QGroupBox("Haploview LD output");
		this.optionsGroupBox=new QGroupBox("Options");
		this.haploviewFormatGroupBox.setEnabled(false);
		
		QLabel inputTypeLabel=new QLabel("Input File Format");
		this.inputTypeTextBox=new QComboBox();
		this.inputTypeTextBox.addItem("Linkage format");
		this.inputTypeTextBox.addItem("Haploview LD output");
		this.inputTypeTextBox.currentIndexChanged.connect(this,"disableGroupBoxes()");
		
		QLabel haploviewLDLabel=new QLabel("Haploview LD file");
		QHBoxLayout haploviewLDLayout=new QHBoxLayout();
		this.haploviewLDTextBox=new QLineEdit();
		haploviewLDLayout.addWidget(this.haploviewLDTextBox);
		QPushButton browseHaploviewLDButton;
		browseHaploviewLDButton=new QPushButton("Browse");
		browseHaploviewLDButton.clicked.connect(this,"browseHaploviewFiles()");
		haploviewLDLayout.addWidget(browseHaploviewLDButton);
		
		QLabel pedLabel=new QLabel("Ped file");
		QHBoxLayout pedLayout=new QHBoxLayout();
		this.pedTextBox=new QLineEdit();
		pedLayout.addWidget(this.pedTextBox);
		QPushButton browsePedButton;
		browsePedButton=new QPushButton("Browse");
		browsePedButton.clicked.connect(this,"browsePedFiles()");
		pedLayout.addWidget(browsePedButton);
		
		QLabel infoLabel=new QLabel("Info file");
		QHBoxLayout infoLayout=new QHBoxLayout();
		this.infoTextBox=new QLineEdit();
		infoLayout.addWidget(infoTextBox);
		QPushButton browseInfoButton;
		browseInfoButton=new QPushButton("Browse");
		browseInfoButton.clicked.connect(this,"browseInfoFiles()");
		infoLayout.addWidget(browseInfoButton);
		
		QLabel freqLabel=new QLabel("Frequency file");
		QHBoxLayout freqLayout=new QHBoxLayout();
		this.freqTextBox=new QLineEdit();
		freqLayout.addWidget(freqTextBox);
		QPushButton browseFreqButton;
		browseFreqButton=new QPushButton("Browse");
		browseFreqButton.clicked.connect(this,"browseFreqFiles()");
		freqLayout.addWidget(browseFreqButton);	
		
		QLabel prefixLabel=new QLabel("Prefix");
		this.prefixTextBox=new QLineEdit();
		
		QLabel chrLabel=new QLabel("Chromosome");
		this.chrTextBox=new QComboBox();
		this.chrTextBox.addItem("1");
		this.chrTextBox.addItem("2");
		this.chrTextBox.addItem("3");
		this.chrTextBox.addItem("4");
		this.chrTextBox.addItem("5");
		this.chrTextBox.addItem("6");
		this.chrTextBox.addItem("7");
		this.chrTextBox.addItem("8");
		this.chrTextBox.addItem("9");
		this.chrTextBox.addItem("10");
		this.chrTextBox.addItem("11");
		this.chrTextBox.addItem("12");
		this.chrTextBox.addItem("13");
		this.chrTextBox.addItem("14");
		this.chrTextBox.addItem("15");
		this.chrTextBox.addItem("16");
		this.chrTextBox.addItem("17");
		this.chrTextBox.addItem("18");
		this.chrTextBox.addItem("19");
		this.chrTextBox.addItem("20");
		this.chrTextBox.addItem("21");
		this.chrTextBox.addItem("22");
		
		QLabel genomeBuildLabel=new QLabel("Genome build");
		this.genomeBuildComboBox=new QComboBox();
		this.genomeBuildComboBox.addItem("hg18");
		this.genomeBuildComboBox.addItem("hg19");
		
		QPushButton submitButton;
		submitButton=new QPushButton("Submit");
		submitButton.clicked.connect(this,"submit()");
		
		mainLayout.addWidget(inputTypeLabel);
		mainLayout.addWidget(inputTypeTextBox);
		
		haploviewFormatLayout.addWidget(haploviewLDLabel);
		haploviewFormatLayout.addItem(haploviewLDLayout);
		this.haploviewFormatGroupBox.setLayout(haploviewFormatLayout);
		mainLayout.addWidget(this.haploviewFormatGroupBox);
		
		linkageFormatLayout.addWidget(pedLabel);
		linkageFormatLayout.addItem(pedLayout);
		this.linkageFormatGroupBox.setLayout(linkageFormatLayout);
		mainLayout.addWidget(this.linkageFormatGroupBox);
		
		optionsLayout.addWidget(infoLabel);
		optionsLayout.addItem(infoLayout);
		optionsLayout.addWidget(freqLabel);
		optionsLayout.addItem(freqLayout);
		optionsLayout.addWidget(prefixLabel);
		optionsLayout.addWidget(prefixTextBox);
		optionsLayout.addWidget(chrLabel);
		optionsLayout.addWidget(chrTextBox);
		optionsLayout.addWidget(genomeBuildLabel);
		optionsLayout.addWidget(genomeBuildComboBox);
		this.optionsGroupBox.setLayout(optionsLayout);
		mainLayout.addWidget(this.optionsGroupBox);
		mainLayout.addWidget(submitButton);
		this.setLayout(mainLayout);
		
		if(this.mainWindow.getIsHaploviewInstalled()==false){
			this.inputTypeTextBox.clear();
			this.inputTypeTextBox.addItem("Haploview LD output");
		}
		this.show();
	}
	
	public void browseHaploviewFiles(){
		String filename=QFileDialog.getOpenFileName(this,tr("Load Haploview LD output file"),this.mainWindow.getServer().getWorkingDir(),new QFileDialog.Filter("Haploview LD Output Files (*.LD)"));
		this.haploviewLDTextBox.setText(filename);

	}
	
	public void browsePedFiles(){
		String filename=QFileDialog.getOpenFileName(this,tr("Load Ped file"),this.mainWindow.getServer().getWorkingDir(),new QFileDialog.Filter("Ped Files (*.ped)"));
		this.pedTextBox.setText(filename);

	}
	
	public void browseInfoFiles(){
		String filename=QFileDialog.getOpenFileName(this,tr("Load Info file"),this.mainWindow.getServer().getWorkingDir(),new QFileDialog.Filter("Info Files (*.info)"));
		this.infoTextBox.setText(filename);
	}
	
	public void browseFreqFiles(){
		String filename=QFileDialog.getOpenFileName(this,tr("Load Frequency file"),this.mainWindow.getServer().getWorkingDir(),new QFileDialog.Filter("Frequency Files (*.frq)"));
		this.freqTextBox.setText(filename);
	}
	
	public void submit(){
		Pattern pattern=Pattern.compile("[^a-z0-9_]", Pattern.CASE_INSENSITIVE);
		Matcher specialCharacter=pattern.matcher(this.prefixTextBox.text());
		if(this.pedTextBox.text().contains(" ")){
			this.handleErrors("Haploview does not accept filename paths containing spaces. " +
					"Please rename the corresponding file or directory accordingly.");
			return;
		}
		else if(this.infoTextBox.text().contains(" ") && 
				this.inputTypeTextBox.currentText().compareTo("Linkage format")==0){
			this.handleErrors("Haploview does not accept filename paths containing spaces. " +
					"Please rename the corresponding file or directory accordingly.");
			return;
		}
		else if(specialCharacter.find()){
			this.handleErrors("Prefix should not contain any special character except '_'. Please choose a " +
					"different prefix");
			return;
		}
		try{
			if(this.inputTypeTextBox.currentText().compareTo("Linkage format")==0 && (this.pedTextBox.text().isEmpty() || this.infoTextBox.text().isEmpty() ||
			   this.freqTextBox.text().isEmpty() || this.prefixTextBox.text().isEmpty()))
				throw new EmptyFieldException();
			else if(this.inputTypeTextBox.currentText().compareTo("Haploview LD output")==0 && (this.haploviewLDTextBox.text().isEmpty() ||
					this.prefixTextBox.text().isEmpty() || this.freqTextBox.text().isEmpty() ||
					this.infoTextBox.text().isEmpty()))
				throw new EmptyFieldException();
			String prefix=this.prefixTextBox.text();
			String filenamePrefix=this.mainWindow.getServer().getWorkingDir()+prefix;
			boolean existsFilesSameName=this.ld.existsFilesSameName(filenamePrefix);
			try{
				boolean existsDatasetSameName=this.ld.existsDatasetSameName(prefix);
				if(!existsFilesSameName && !existsDatasetSameName){
					if(!this.ld.isFreqFileCompatible(this.freqTextBox.text())){
						QMessageBox box=new QMessageBox(QMessageBox.Icon.Warning,"Error","Problem with" +
								" the freq file format! " +
								"Please ensure that the file follows the specifications.");
						box.show();
					}else if(!this.ld.isInfoFileCompatible(this.infoTextBox.text())){
						QMessageBox box=new QMessageBox(QMessageBox.Icon.Warning,"Error","Problem with" +
								" the info file format! " +
								"Please ensure that the file follows the specifications.");
						box.show();
					}else if(this.inputTypeTextBox.currentText().compareTo("Haploview LD output")==0 && 
							!this.ld.isLDFileCompatible(this.haploviewLDTextBox.text())){
						QMessageBox box=new QMessageBox(QMessageBox.Icon.Warning,"Error","Problem with" +
								" the Haploview LD file format! " +
								"Please ensure that the file follows the specifications.");
						box.show();
					}
					else{
						this.computeLD();
					}
				}else if(existsFilesSameName && !existsDatasetSameName){
					QMessageBox box=new QMessageBox(QMessageBox.Icon.Question,"Error","The software needs to create temporary files," +
							"with the following extensions: .LD, .info.blocks, .snps.blocks, .complete.ld, .ld. The working directory" +
							" already contains one or more files with these extension and the chosen prefix. Do you want to overwrite them?");
					box.addButton(QMessageBox.StandardButton.No);
					QPushButton yes=box.addButton(QMessageBox.StandardButton.Yes);
					box.setDefaultButton(QMessageBox.StandardButton.No);
					box.show();
					yes.clicked.connect(this,"overwrite()");
				}else{
	
					QMessageBox box=new QMessageBox(QMessageBox.Icon.Warning,"Error","The database already contains a dataset called "+
							this.prefixTextBox.text()+
							". Please choose a different prefix.");
					box.show();
				}
			}catch(LinkageDisequilibriumException e){
				this.handleErrors(e.getMessage());
			}
		}catch(EmptyFieldException e){
			this.handleErrors(e.getMessage());
		}
	}
	
	private void overwrite(){
		this.computeLD();
	}
	
	private void computeLD(){
		this.startProgressBar();
		String prefix=this.prefixTextBox.text();
		if(this.inputTypeTextBox.currentText().compareTo("Linkage format")==0){
			String filenamePrefix=this.mainWindow.getServer().getWorkingDir()+prefix;
			String haploviewFilename=filenamePrefix+".LD";
			this.processingThread=new ProcessingThreadLinkage(this.ld,this.mainWindow.getServer().getHaploviewPath(),
				this.pedTextBox.text(),this.infoTextBox.text(),haploviewFilename,prefix,
				this.chrTextBox.currentText(),this.genomeBuildComboBox.currentText(),
				this.freqTextBox.text(),this.mainWindow.getServer().getWorkingDir());
		}else{
			String haploviewFilename=this.haploviewLDTextBox.text();
			this.processingThread=new ProcessingThreadLinkage(this.ld,haploviewFilename,prefix,
					this.chrTextBox.currentText(),this.genomeBuildComboBox.currentText(),
					this.freqTextBox.text(),this.infoTextBox.text(),this.mainWindow.getServer().getWorkingDir());
		}
		this.processingThread.datasetLoaded.connect(this,"datasetLoaded()");
		this.processingThread.error.connect(this,"handleErrors(String)");
		QThreadPool pool=new QThreadPool();
		pool.start(this.processingThread);
		this.close();
	}
	
	private void datasetLoaded(){
		this.progressBarDialog.hide();
		if(this.error==false){
			QMessageBox box=new QMessageBox(QMessageBox.Icon.NoIcon,"Dataset","Dataset loaded!");
			box.show();
		}
		this.mainWindow.enableActions();
	}
	
	private void startProgressBar(){
		this.progressBarDialog=new QDialog();
		QVBoxLayout progressBarLayout=new QVBoxLayout();
		progressBarDialog.setWindowTitle("Progress");
		QProgressBar progressBar=new QProgressBar();
		QLabel progressLabel=new QLabel("Processing...");
		progressLabel.setAlignment(Qt.AlignmentFlag.AlignLeft);
		progressBarLayout.addWidget(progressLabel);
		progressBar.setAlignment(Qt.AlignmentFlag.AlignHCenter);
		progressBar.setMinimum(0);
		progressBar.setMaximum(0);
		progressBarLayout.addWidget(progressBar);
		this.progressBarDialog.setLayout(progressBarLayout);
        this.progressBarDialog.show();
		this.update();
		this.repaint();
		QApplication.processEvents();
	}
	
	private void handleErrors(String errorMsg){
		QMessageBox box=new QMessageBox(QMessageBox.Icon.Warning,"Error",errorMsg);
		box.show();
		this.error=true;
		this.progressBarDialog.hide();
	}
	
	private void disableGroupBoxes(){
		if(this.inputTypeTextBox.currentText().compareTo("Linkage format")==0){
			this.haploviewFormatGroupBox.setEnabled(false);
			this.linkageFormatGroupBox.setEnabled(true);
		}
		else{
			this.haploviewFormatGroupBox.setEnabled(true);
			this.linkageFormatGroupBox.setEnabled(false);
		}
	}
}
