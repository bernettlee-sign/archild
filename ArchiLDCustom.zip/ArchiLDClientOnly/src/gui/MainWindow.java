/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package gui;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.trolltech.qt.core.QFile;
import com.trolltech.qt.core.QUrl;
import com.trolltech.qt.gui.*;

import core_server.MySQLConnection;
import core_server.Server;
import exceptions.LinkageDisequilibriumException;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class MainWindow extends QMainWindow{
	/**
	 * Main drop-down menu to create a new architecture
	 */
	private QMenu fileMenu;
	/**
	 * Drop-down menu to visualize software documentation and features
	 */
	private QMenu helpMenu;
	/**
	 * Action to exit from the application
	 */
	private QAction exitFromApplicationAction;
	/**
	 * Action to create a new architecture
	 */
	private QAction newArchitectureAction;
	/**
	 * Action to retrieve software documentation 
	 */
	private QAction manualAction;
	/**
	 * Action to show software info
	 */
	private QAction aboutAction;
	/**
	 * Action to set up parameters
	 */
	private QAction setUpParametersAction;
	/**
	 * Action to load a dataset
	 */
	private QAction loadDatasetAction;
	/**
	 * Navigation Tree
	 */
	private NavigationTree navigationTree;
	/**
	 * Plot to show hierarchical clustering results
	 */
	private ClusteringPlot clusteringPlot;
	private Browser browser;
	private Server server;
	private ArrayList<String> filesCreated;
	private boolean isHaploviewInstalled;
	private Legend legend;
	private QGridLayout mainLayout;

	/**
	 * Main method
	 * @param args
	 */
	public static void main(String[] args) {
		QApplication.initialize(args);
		MainWindow mainWindow = new MainWindow();
        mainWindow.resize(1300, 648);
        mainWindow.show();
        QApplication.exec();
	}
	/**
	 * Constructor, it sets all the actions, the menus, the navigation tree, the clustering plot and the browser
	 */
	public MainWindow(){
		this.createActions();
		this.createMenus();
        this.clusteringPlot=new ClusteringPlot();
		this.navigationTree=new NavigationTree(this);
        this.browser = new Browser();
        this.clusteringPlot.setVisible(false);
		QWidget centralWidget=new QWidget();
		this.mainLayout=new QGridLayout();
		QSplitter bottomSplitter=new QSplitter();
		this.legend=new Legend();
		mainLayout.addWidget(this.legend,0,0);
		bottomSplitter.addWidget(navigationTree);
		bottomSplitter.addWidget(clusteringPlot);
		bottomSplitter.addWidget(browser);
		bottomSplitter.setCollapsible(0, true);
		bottomSplitter.setCollapsible(1, true);
		mainLayout.addWidget(bottomSplitter,1,0);
		centralWidget.setLayout(mainLayout);
		this.disableLegend();
		this.setCentralWidget(centralWidget);
		this.setWindowTitle("ArchiLD");
		if(this.server==null){
			this.loadDatasetAction.setEnabled(false);
			this.newArchitectureAction.setEnabled(false);
		}
		this.filesCreated=new ArrayList<String>();
	}
	/**
	 * Creates drop down menus
	 */
	private void createMenus(){
        this.fileMenu=menuBar().addMenu(tr("File"));
        this.fileMenu.addAction(this.setUpParametersAction);
        this.fileMenu.addAction(this.loadDatasetAction);
        this.fileMenu.addAction(this.newArchitectureAction);
        this.fileMenu.addAction(this.exitFromApplicationAction);
        this.helpMenu=menuBar().addMenu(tr("Help"));
        this.helpMenu.addAction(this.manualAction);
        this.helpMenu.addAction(this.aboutAction);
	}
	/**
	 * Creates all the actions
	 */
	private void createActions(){     
        // Close window 
    	this.exitFromApplicationAction = new QAction(tr("Exit"), this);
    	this.exitFromApplicationAction.triggered.connect(this, "close()");
    	// Create an architecture
    	this.newArchitectureAction=new QAction(tr("New"),this);
    	this.newArchitectureAction.triggered.connect(this,"newArchitecture()");    	
    	// Show manual
    	this.manualAction=new QAction(tr("Manual"),this);
    	this.manualAction.triggered.connect(this,"showManual()");
    	// Show about
    	this.aboutAction=new QAction(tr("About"),this);
    	this.aboutAction.triggered.connect(this,"showAbout()");
    	// Set up parameters
    	this.setUpParametersAction=new QAction(tr("Set up parameters"),this);
    	this.setUpParametersAction.triggered.connect(this,"setUpParameters()");
    	// Load dataset
    	this.loadDatasetAction=new QAction(tr("Load dataset"),this);
    	this.loadDatasetAction.triggered.connect(this,"loadDataset()");
	}
	/**
	 * Open an architecture window to generate a new architecture
	 * A new architecture can be created only if the connection parameters have already been set
	 */
	private void newArchitecture(){
		if(this.server!=null){
			new ArchitectureWindow(this);
		}
		else{
			this.handleErrors("Connection parameters not set");
		}
	}
	/**
	 * 
	 * @return the navigation tree associated to the session
	 */
	public NavigationTree getNavigationTree(){
		return this.navigationTree;
	}
	/**
	 * 
	 * @return the clustering plot associated to the session
	 */
	public ClusteringPlot getClusteringPlot(){
		return this.clusteringPlot;
	}
	
	public Browser getBrowser(){
		return this.browser;
	}
	/**
	 * Show software documentation
	 */
	public void showManual(){
		QUrl url=new QUrl("http://archild.sign.a-star.edu.sg/ArchiLDManualVM.pdf");
		QDesktopServices.openUrl(url);
	}
	/**
	 * Show about box
	 */
	public void showAbout(){
		new AboutWindow();
	}
	/**
	 * Set up parameters
	 */
	public void setUpParameters(){
		new ParametersWindow(this);
	}
	/**
	 * Set server
	 */
	public void setServer(Server server){
		this.server=server;
	}
	/**
	 * Get server
	 */
	public Server getServer(){
		return this.server;
	}
	
	private void handleErrors(String errorMsg){
		QMessageBox box=new QMessageBox(QMessageBox.Icon.Critical,"Error",errorMsg);
		box.show();
	}
	
	public void loadDataset(){
		if(this.server!=null){
			new LoadDatasetWindow(this);
		}
		else{
			this.handleErrors("Connection parameters not set");
		}
	}
	
	public void enableActions(){
		this.loadDatasetAction.setEnabled(true);
		MySQLConnection conn=this.getServer().getMySQLConnection();
		Statement stmt;
		try {
			if(this.doesTableExists("datasets")){
				try {
					stmt = conn.getConnection().createStatement();
					ResultSet rs=stmt.executeQuery("SELECT COUNT(prefix) FROM datasets");
					while(rs.next()){
						int numberDatasets=rs.getInt(1);
						if(numberDatasets>0)
							this.newArchitectureAction.setEnabled(true);
					}
					rs.close();
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} catch (LinkageDisequilibriumException e) {
			e.printStackTrace();
		}
	}
	
	public void disableNewArchitectureAction(){
		this.newArchitectureAction.setEnabled(false);
	}
	
	@Override
	protected void closeEvent(QCloseEvent arg__1) {
		for(String filename:this.filesCreated){
			QFile file=new QFile(filename);
			file.remove();
		}
		// Delete all temporary files created during the session
		super.closeEvent(arg__1);
	}
	
	public void addFileToFilesCreated(String filename){
		this.filesCreated.add(filename);
	}
	
	public void setIsHaploviewInstalled(boolean isInstalled){
		this.isHaploviewInstalled=isInstalled;
	}
	
	public boolean getIsHaploviewInstalled(){
		return this.isHaploviewInstalled;
	}
	
	private boolean doesTableExists(String tableName) throws LinkageDisequilibriumException{
		MySQLConnection conn=this.getServer().getMySQLConnection();
		Statement stmt;
		ResultSet rs;
		try{
			stmt=conn.getConnection().createStatement();
			rs=stmt.executeQuery("SELECT table_name FROM information_schema.tables WHERE table_schema='"+
					conn.getDatabase()+"' AND table_name='"+tableName+"'");
			if(!rs.isBeforeFirst())
				return false;
			rs.close();
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    throw new LinkageDisequilibriumException(e.getMessage());
		}
		return true;
	}
	
	public void enableLegend(){
		this.legend.show();
		this.mainLayout.setContentsMargins(11, 0, 11, 11);
	}
	
	public void disableLegend(){
		this.legend.hide();
		this.mainLayout.setContentsMargins(11, 11, 11, 11);
	}
}
