/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package gui;

import com.trolltech.qt.core.Qt.AlignmentFlag;
import com.trolltech.qt.gui.QColor;
import com.trolltech.qt.gui.QGridLayout;
import com.trolltech.qt.gui.QLabel;
import com.trolltech.qt.gui.QPalette;
import com.trolltech.qt.gui.QPalette.ColorRole;
import com.trolltech.qt.gui.QWidget;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class Legend extends QWidget{
	public Legend(){
		this.setMinimumHeight(60);
		this.setMaximumWidth(800);
		QGridLayout layout=new QGridLayout();
		layout.setWidgetSpacing(0);
		layout.setHorizontalSpacing(0);
		layout.setVerticalSpacing(0);
		
		QLabel title=new QLabel("Minor allele frequency");
		title.setFixedWidth(150);
		layout.addWidget(title,0,0);
		
		QLabel firstBox=new QLabel("<5%");		
		firstBox.setFixedWidth(60);
		firstBox.setFixedHeight(60);
		firstBox.setAlignment(AlignmentFlag.AlignCenter);
		QPalette firstPalette=new QPalette();
		firstPalette.setColor(ColorRole.Window, new QColor(0,255,0));
		firstBox.setAutoFillBackground(true);
		firstBox.setPalette(firstPalette);
		layout.addWidget(firstBox,0,1);
		
		QLabel secondBox=new QLabel("5-10%");
		secondBox.setFixedWidth(60);
		secondBox.setFixedHeight(60);
		secondBox.setAlignment(AlignmentFlag.AlignCenter);
		QPalette secondPalette=new QPalette();
		secondPalette.setColor(ColorRole.Window, new QColor(113,255,0));
		secondBox.setAutoFillBackground(true);
		secondBox.setPalette(secondPalette);
		layout.addWidget(secondBox,0,2);
		
		QLabel thirdBox=new QLabel("10-15%");
		thirdBox.setFixedWidth(60);
		thirdBox.setFixedHeight(60);
		thirdBox.setAlignment(AlignmentFlag.AlignCenter);
		QPalette thirdPalette=new QPalette();
		thirdPalette.setColor(ColorRole.Window, new QColor(226,255,0));
		thirdBox.setAutoFillBackground(true);
		thirdBox.setPalette(thirdPalette);
		layout.addWidget(thirdBox,0,3);
		
		QLabel fourthBox=new QLabel("15-20%");
		fourthBox.setFixedWidth(60);
		fourthBox.setFixedHeight(60);
		fourthBox.setAlignment(AlignmentFlag.AlignCenter);
		QPalette fourthPalette=new QPalette();
		fourthPalette.setColor(ColorRole.Window, new QColor(255,170,0));
		fourthBox.setAutoFillBackground(true);
		fourthBox.setPalette(fourthPalette);
		layout.addWidget(fourthBox,0,4);
		
		QLabel fifthBox=new QLabel("20-25%");
		fifthBox.setFixedWidth(60);
		fifthBox.setFixedHeight(60);
		fifthBox.setAlignment(AlignmentFlag.AlignCenter);
		QPalette fifthPalette=new QPalette();
		fifthPalette.setColor(ColorRole.Window, new QColor(255,56,0));
		fifthBox.setAutoFillBackground(true);
		fifthBox.setPalette(fifthPalette);
		layout.addWidget(fifthBox,0,5);
		
		QLabel sixthBox=new QLabel("25-30%");
		sixthBox.setFixedWidth(60);
		sixthBox.setFixedHeight(60);
		sixthBox.setAlignment(AlignmentFlag.AlignCenter);
		QPalette sixthPalette=new QPalette();
		sixthPalette.setColor(ColorRole.Window, new QColor(255,0,56));
		sixthBox.setAutoFillBackground(true);
		sixthBox.setPalette(sixthPalette);
		layout.addWidget(sixthBox,0,6);
		
		QLabel seventhBox=new QLabel("30-35%");
		seventhBox.setFixedWidth(60);
		seventhBox.setFixedHeight(60);
		seventhBox.setAlignment(AlignmentFlag.AlignCenter);
		QPalette seventhPalette=new QPalette();
		seventhPalette.setColor(ColorRole.Window, new QColor(255,0,170));
		seventhBox.setAutoFillBackground(true);
		seventhBox.setPalette(seventhPalette);
		layout.addWidget(seventhBox,0,7);
		
		QLabel eightBox=new QLabel("35-40%");
		eightBox.setFixedWidth(60);
		eightBox.setFixedHeight(60);
		eightBox.setAlignment(AlignmentFlag.AlignCenter);
		QPalette eightPalette=new QPalette();
		eightPalette.setColor(ColorRole.Window, new QColor(226,0,255));
		eightBox.setAutoFillBackground(true);
		eightBox.setPalette(eightPalette);
		layout.addWidget(eightBox,0,8);
		
		QLabel ninthBox=new QLabel("40-45%");
		ninthBox.setFixedWidth(60);
		ninthBox.setFixedHeight(60);
		ninthBox.setAlignment(AlignmentFlag.AlignCenter);
		QPalette ninthPalette=new QPalette();
		ninthPalette.setColor(ColorRole.Window, new QColor(113,0,255));
		ninthBox.setAutoFillBackground(true);
		ninthBox.setPalette(ninthPalette);
		layout.addWidget(ninthBox,0,9);
		
		QLabel tenthBox=new QLabel("45-50%");
		tenthBox.setFixedWidth(60);
		tenthBox.setFixedHeight(60);
		tenthBox.setAlignment(AlignmentFlag.AlignCenter);
		QPalette tenthPalette=new QPalette();
		tenthPalette.setColor(ColorRole.Window, new QColor(0,0,255));
		tenthBox.setAutoFillBackground(true);
		tenthBox.setPalette(tenthPalette);
		layout.addWidget(tenthBox,0,10);
		
		this.setLayout(layout);
	}
}
