/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package gui;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Hashtable;

import com.trolltech.qt.core.QFile;
import com.trolltech.qt.core.Qt;
import com.trolltech.qt.gui.QAction;
import com.trolltech.qt.gui.QContextMenuEvent;
import com.trolltech.qt.gui.QFileDialog;
import com.trolltech.qt.gui.QMenu;
import com.trolltech.qt.gui.QMessageBox;
import com.trolltech.qt.gui.QMouseEvent;
import com.trolltech.qt.gui.QTreeWidget;
import com.trolltech.qt.gui.QTreeWidgetItem;
import com.trolltech.qt.network.QHttp;

import core.Architecture;
import core.Cluster;
import core.RequestKey;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class NavigationTree extends QTreeWidget{
	/**
	 * Hashtable linking QTreeWidgetItem with the architecture object they represent
	 */
	private Hashtable<QTreeWidgetItem,RequestKey> tableArchitectures;
	/**
	 * Hashtable linking QtreeWidgetItem with the cluster object they represent
	 */
	private Hashtable<QTreeWidgetItem,Cluster> tableClusters;
	/**
	 * Menu track
	 */
	private QMenu menuTrack;
	/**
	 * Menu cluster
	 */
	private QMenu menuCluster;
	/**
	 * Action to download track
	 */
	private QAction downloadTrack;
	/**
	 * Action to download cluster
	 */
	private QAction downloadCluster;
	/**
	 * Selected item in the navigation tree
	 */
	private QTreeWidgetItem selectedItem;
	/**
	 * Link to the MainWindow
	 */
	private MainWindow mainWindow;
	/**
	 * Http connection
	 */
	private QHttp http;
	/**
	 * File
	 */
	private File file;
	
	/**
	 * Constructs a navigation tree from a clustering plot
	 * @param clusteringPlot
	 */
	public NavigationTree(MainWindow mainWindow){
		this.mainWindow=mainWindow;
		this.tableArchitectures=new Hashtable<QTreeWidgetItem,RequestKey>();
		this.tableClusters=new Hashtable<QTreeWidgetItem,Cluster>();
		this.setHeaderLabel("LD Architectures");
		createActions();
		createMenus();
	}	
	/**
	 * Creates contextual menus
	 */
	private void createMenus(){
        this.menuTrack=new QMenu();
        this.menuTrack.addAction(this.downloadTrack);
        this.menuCluster=new QMenu();
        this.menuCluster.addAction(this.downloadCluster);
	}
	/**
	 * Creates actions
	 */
	private void createActions(){     
    	// Download track
    	this.downloadTrack=new QAction(tr("Download track"),this);
    	this.downloadTrack.triggered.connect(this,"downloadTrack()");
    	// Download cluster
    	this.downloadCluster=new QAction(tr("Download cluster"),this);
    	this.downloadCluster.triggered.connect(this,"downloadCluster()");
	}
	/**
	 * Add an architecture to the navigation tree as a father less element
	 * @param architecture architecture to add
	 * @param type type of architecture {SNP,Gene,Chr}
	 */
	public void addArchitecture(RequestKey requestKey,String type,boolean singletons,String name,
			boolean colorByMAF){
		QTreeWidgetItem item=new QTreeWidgetItem(this);
		item.setText(0,name);
		item.setText(1,type);
		item.setText(2,String.valueOf(singletons));
		item.setText(3, String.valueOf(colorByMAF));
		this.tableArchitectures.put(item,requestKey);
		String urlAddress=this.mainWindow.getServer().getWorkingDir()+requestKey.getKey()+".xml";
		Architecture architecture=new Architecture(urlAddress);
		for(Cluster cluster:architecture.getClusters()){
			QTreeWidgetItem clusterItem=addCluster("Cluster",cluster.getTagSNP(),item,cluster);
			this.tableClusters.put(clusterItem,cluster);
			for(String snp: cluster.getSnpIds())
				addSNP("Variant",snp,clusterItem);
		}
	}
	/**
	 * Add an architecture to the navigation tree as a child of an existing item
	 * @param architecture architecture architecture to add
	 * @param type type of architecture {Cluster,Variant}
	 * @param father father item
	 */
	public QTreeWidgetItem addCluster(String type,String name,QTreeWidgetItem father,Cluster cluster){
		QTreeWidgetItem item=new QTreeWidgetItem(father);
		item.setText(0,name);
		item.setText(1,type);
		//this.tableClusters.put(item,cluster);
		return item;
	}
	
	public QTreeWidgetItem addSNP(String type,String name,QTreeWidgetItem father){
		QTreeWidgetItem item=new QTreeWidgetItem(father);
		item.setText(0,name);
		item.setText(1,type);
		return item;
	}

	@Override
	protected void contextMenuEvent(QContextMenuEvent event) {
		Object o=this.itemAt(event.pos());
		if(o!=null && o instanceof QTreeWidgetItem){
			if(tableArchitectures.containsKey(o)){
				this.selectedItem=(QTreeWidgetItem)o;
				String filename="";
				if(this.selectedItem.text(1).compareTo("Chr")==0)
					filename=this.mainWindow.getServer().getWorkingDir()+this.tableArchitectures.get(this.selectedItem).getKey()+".track";
				else
					filename=this.mainWindow.getServer().getWorkingDir()+this.tableArchitectures.get(this.selectedItem).getKey()+".track";
				if(exists(filename)){
					this.menuTrack.popup(event.globalPos());
					this.menuTrack.show();
				}else{
					String errorMsg="The corresponding file has been deleted from the server " +
					"(files are automatically deleted every 3 days). Please re-run the query.";
					QMessageBox box=new QMessageBox(QMessageBox.Icon.Warning,"Error",errorMsg);
					box.show();
				}
			}else if(tableClusters.containsKey(o)){
				this.selectedItem=(QTreeWidgetItem)o;
				this.menuCluster.popup(event.globalPos());
				this.menuCluster.show();
			}
		}
		super.contextMenuEvent(event);
	}
	/**
	 * Shows the dendrogram plot
	 */
	public void showDendrogram(){
		String filename=this.mainWindow.getServer().getWorkingDir()+
		this.tableArchitectures.get(this.selectedItem).getKey()+".ordered.ld.png";
		this.mainWindow.getClusteringPlot().setPlot(filename);
		//this.mainWindow.getClusteringPlot().set(350);
		this.mainWindow.getClusteringPlot().setVisible(true);
	}
	/**
	 * Hides the dendrogram plot
	 */
	public void hideDendrogram(){
		this.mainWindow.getClusteringPlot().setVisible(false);
	}
	
	public void showInUCSC(){
		String url;
		String filenameStatic=this.mainWindow.getServer().getWorkingDir()+this.tableArchitectures.get(this.selectedItem).getKey()+".track";
		if(exists(filenameStatic)){
			if(this.selectedItem.text(0).contains("hg18")){
				url="http://genome.ucsc.edu/cgi-bin/hgTracks?db=hg18&ctfile_hg18=";
			}else{
				url="http://genome.ucsc.edu/cgi-bin/hgTracks?db=hg19&ctfile_hg19=";			}
			this.mainWindow.getBrowser().setUrl(url);
		}else{
			String errorMsg="The corresponding file has been deleted from the working directory."+
					"Please re-run the query.";
			QMessageBox box=new QMessageBox(QMessageBox.Icon.Warning,"Error",errorMsg);
			box.show();
		}
	}
	/**
	 * Export UCSC tracks
	 * The method used for the export is different according to the type of the architecture to export
	 */
	public void downloadTrack(){		
		try {
			String defaultFilename=this.mainWindow.getServer().getWorkingDir()+this.selectedItem.text(0)+".track";
			String filename=QFileDialog.getSaveFileName(this,tr("Download track"),
					defaultFilename,new QFileDialog.Filter("Ucsc track Files (*.track)"));
			String temporaryFilename;
			if(this.selectedItem.text(1).compareTo("Chr")==0)
				temporaryFilename=this.mainWindow.getServer().getWorkingDir()+this.tableArchitectures.get(this.selectedItem).getKey()+".track";
			else
				temporaryFilename=this.mainWindow.getServer().getWorkingDir()+this.tableArchitectures.get(this.selectedItem).getKey()+".track";;
			BufferedReader temporaryFile=new BufferedReader(new FileReader(temporaryFilename));
			BufferedWriter file=new BufferedWriter(new FileWriter(filename));
			String line;
			while((line = temporaryFile.readLine()) != null) {
				file.write(line+"\n");
			}
			temporaryFile.close();
			file.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void downloadCluster(){
		Cluster cluster=this.tableClusters.get(this.selectedItem);
		String defaultFilename=this.mainWindow.getServer().getWorkingDir()+this.selectedItem.text(0)+".txt";
		String filename=QFileDialog.getSaveFileName(this,tr("Download cluster"),defaultFilename,
				new QFileDialog.Filter("Text Files (*.txt)"));
		cluster.export(filename);
	}
	
	@Override
	protected void mousePressEvent(QMouseEvent event) {
		if(event.button().compareTo(Qt.MouseButton.LeftButton)==0){
			Object o=this.itemAt(event.pos());
			if(o!=null && o instanceof QTreeWidgetItem){
				if(tableArchitectures.containsKey(o)){
					this.selectedItem=(QTreeWidgetItem)o;
					if(Boolean.parseBoolean(this.selectedItem.text(3))==true){
						this.mainWindow.enableLegend();
					}
					else{
						this.mainWindow.disableLegend();
					}
					if(this.selectedItem.text(0).contains("hierarchical")){
						this.showInUCSC();
						this.showDendrogram();
						this.mainWindow.getClusteringPlot().setMinimumWidth(330);
						this.mainWindow.getBrowser().setMinimumWidth(924);
					}
					else{
						this.showInUCSC();
						this.hideDendrogram();
					}
				}else if(tableClusters.containsKey(o)){
					this.selectedItem=(QTreeWidgetItem)o;
				}
			}
		}
		super.mousePressEvent(event);
	}
	
	private static boolean exists(String filename){
		File f=new File(filename);
		return f.exists();
	}
}