/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package gui;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import com.trolltech.qt.core.Qt;
import com.trolltech.qt.gui.QCheckBox;
import com.trolltech.qt.gui.QDialog;
import com.trolltech.qt.gui.QFileDialog;
import com.trolltech.qt.gui.QGroupBox;
import com.trolltech.qt.gui.QHBoxLayout;
import com.trolltech.qt.gui.QLabel;
import com.trolltech.qt.gui.QLineEdit;
import com.trolltech.qt.gui.QMessageBox;
import com.trolltech.qt.gui.QLineEdit.EchoMode;
import com.trolltech.qt.gui.QPushButton;
import com.trolltech.qt.gui.QVBoxLayout;

import core_server.MySQLConnection;
import core_server.Server;
import exceptions.ConnectionErrorException;
import exceptions.EmptyFieldException;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class ParametersWindow extends QDialog{
	QLineEdit usernameMySQLTextBox;
	QLineEdit passwordMySQLTextBox;
	QLineEdit hostMySQLTextBox;
	QLineEdit databaseMySQLTextBox;
	QLineEdit workingDirTextBox;
	QLineEdit RPathTextBox;
	QLineEdit HaploviewPathTextBox;
	QLineEdit saveParameterFileTextBox;
	QLineEdit loadParameterFileTextBox;
	QGroupBox generalBox;
	QGroupBox loadBox;
	QCheckBox saveParametersCheckBox;
	QCheckBox loadParametersCheckBox;
	QPushButton browseSaveFileButton;
	QPushButton browseLoadFileButton;
	MainWindow mainWindow;
	
	public ParametersWindow(MainWindow mainWindow){
		this.mainWindow=mainWindow;
		
		QVBoxLayout mainLayout=new QVBoxLayout();
		QHBoxLayout columnLayout=new QHBoxLayout();
		QVBoxLayout firstColumnLayout=new QVBoxLayout();
		
		this.loadBox=new QGroupBox("Load Parameters");
		QVBoxLayout loadLayout=new QVBoxLayout();
		QHBoxLayout loadBrowseLayout=new QHBoxLayout();
		this.loadParametersCheckBox=new QCheckBox("Load parameters");
		this.loadParameterFileTextBox=new QLineEdit();
		this.loadParameterFileTextBox.setVisible(false);
		this.browseLoadFileButton=new QPushButton("Browse");
		this.browseLoadFileButton.clicked.connect(this,"browseLoadDirectory()");
		this.browseLoadFileButton.setVisible(false);
		this.loadParametersCheckBox.stateChanged.connect(this,"setVisibilityChoiceLoadParameterFile()");
		loadLayout.addWidget(this.loadParametersCheckBox);
		loadBrowseLayout.addWidget(this.loadParameterFileTextBox);
		loadBrowseLayout.addWidget(this.browseLoadFileButton);
		loadLayout.addItem(loadBrowseLayout);
		loadBox.setLayout(loadLayout);
		firstColumnLayout.addWidget(loadBox);
		
		this.generalBox=new QGroupBox("General");
		QVBoxLayout generalLayout=new QVBoxLayout();
		QPushButton submitButton=new QPushButton("Submit");
		submitButton.clicked.connect(this,"submit()");
		QLabel workingDirLabel=new QLabel("Working directory");
		this.workingDirTextBox=new QLineEdit();
		QPushButton browseWorkingDirButton=new QPushButton("Browse");
		browseWorkingDirButton.clicked.connect(this,"browseWorkingDir()");
		QHBoxLayout browseWorkingDirLayout=new QHBoxLayout();
		browseWorkingDirLayout.addWidget(this.workingDirTextBox);
		browseWorkingDirLayout.addWidget(browseWorkingDirButton);
		
		QLabel RPathLabel=new QLabel("R Path");
		this.RPathTextBox=new QLineEdit();
		QPushButton browseRPathButton=new QPushButton("Browse");
		browseRPathButton.clicked.connect(this,"browseRPath()");
		QHBoxLayout browseRPathLayout=new QHBoxLayout();
		browseRPathLayout.addWidget(this.RPathTextBox);
		browseRPathLayout.addWidget(browseRPathButton);
			
		QLabel HaploviewPathLabel=new QLabel("Haploview Path (optional)");
		this.HaploviewPathTextBox=new QLineEdit();
		QPushButton browseHaploviewPathButton=new QPushButton("Browse");
		browseHaploviewPathButton.clicked.connect(this,"browseHaploviewPath()");
		QHBoxLayout browseHaploviewPathLayout=new QHBoxLayout();
		browseHaploviewPathLayout.addWidget(this.HaploviewPathTextBox);
		browseHaploviewPathLayout.addWidget(browseHaploviewPathButton);
		
		QLabel usernameMySQLNameLabel=new QLabel("MySQL username");
		this.usernameMySQLTextBox=new QLineEdit();
		QLabel passwordMySQLNameLabel=new QLabel("MySQL password");
		this.passwordMySQLTextBox=new QLineEdit();
		this.passwordMySQLTextBox.setEchoMode(EchoMode.Password);
		QLabel hostMySQLNameLabel=new QLabel("MySQL host");
		this.hostMySQLTextBox=new QLineEdit();
		QLabel databaseMySQLNameLabel=new QLabel("MySQL database");
		this.databaseMySQLTextBox=new QLineEdit();
		
		this.saveParametersCheckBox=new QCheckBox("Save parameters");
		saveParametersCheckBox.stateChanged.connect(this,"setVisibilityChoiceSaveParameterFile()");
		this.saveParameterFileTextBox=new QLineEdit();		
		this.browseSaveFileButton=new QPushButton("Browse");
		this.browseSaveFileButton.clicked.connect(this,"browseSaveDirectory()");
		this.saveParameterFileTextBox.setVisible(false);
		this.browseSaveFileButton.setVisible(false);
		generalLayout.addWidget(workingDirLabel);
		generalLayout.addItem(browseWorkingDirLayout);
		
		generalLayout.addWidget(usernameMySQLNameLabel);
		generalLayout.addWidget(this.usernameMySQLTextBox);
		generalLayout.addWidget(passwordMySQLNameLabel);
		generalLayout.addWidget(this.passwordMySQLTextBox);
		generalLayout.addWidget(hostMySQLNameLabel);
		generalLayout.addWidget(this.hostMySQLTextBox);
		generalLayout.addWidget(databaseMySQLNameLabel);
		generalLayout.addWidget(this.databaseMySQLTextBox);
		
		generalLayout.addWidget(RPathLabel);
		generalLayout.addItem(browseRPathLayout);
		generalLayout.addWidget(HaploviewPathLabel);
		generalLayout.addItem(browseHaploviewPathLayout);
		generalLayout.addWidget(this.saveParametersCheckBox);
		QHBoxLayout saveParametersLayout=new QHBoxLayout();
		saveParametersLayout.addWidget(this.saveParameterFileTextBox);
		saveParametersLayout.addWidget(browseSaveFileButton);
		generalLayout.addItem(saveParametersLayout);
		generalLayout.setSpacing(1);
		generalBox.setLayout(generalLayout);		
		
		columnLayout.addItem(firstColumnLayout);
		columnLayout.addWidget(generalBox,1,Qt.AlignmentFlag.AlignTop);
		mainLayout.addItem(columnLayout);
		mainLayout.addWidget(submitButton,1,Qt.AlignmentFlag.AlignLeft);
		this.setLayout(mainLayout);
		this.setWindowTitle("Settings");
		this.setMinimumSize(800, 400);
		this.show();
	}
	public void submit(){
		if(this.workingDirTextBox.text().contains(" ")){
			this.handleErrors("The working directory cannot contain any space. Please choose a different directory or rename it.");
		}
		try{
			if(this.workingDirTextBox.text().isEmpty() || this.usernameMySQLTextBox.text().isEmpty() || 
				this.passwordMySQLTextBox.text().isEmpty() || this.hostMySQLTextBox.text().isEmpty() || this.databaseMySQLTextBox.text().isEmpty() ||
				this.RPathTextBox.text().isEmpty())
				throw new EmptyFieldException();
			else {
				if(this.HaploviewPathTextBox.text().isEmpty()){
					this.mainWindow.setIsHaploviewInstalled(false);
				}
				else{
					this.mainWindow.setIsHaploviewInstalled(true);
				}
				Server server=new Server(this.hostMySQLTextBox.text(),this.databaseMySQLTextBox.text(),
					this.usernameMySQLTextBox.text(),this.passwordMySQLTextBox.text(),
	    			this.RPathTextBox.text(),this.HaploviewPathTextBox.text(),this.workingDirTextBox.text(),
	    			this.mainWindow);
				this.mainWindow.setServer(server);
				if(this.saveParametersCheckBox.isChecked())
					this.saveParameters(this.saveParameterFileTextBox.text());
				this.close();
				this.mainWindow.enableActions();
			}
		}catch(ConnectionErrorException e){
			this.handleErrors(e.getMessage());
		} catch (EmptyFieldException e) {
			this.handleErrors(e.getMessage());
		}

	}
	public void browseSaveDirectory(){
		String filename=QFileDialog.getSaveFileName(this,tr("Save file"),null,new QFileDialog.Filter("Text Files (*.txt)"));
		this.saveParameterFileTextBox.setText(filename);
	}
	public void browseLoadDirectory(){
		String filename=QFileDialog.getOpenFileName(this,tr("Load file"),null,new QFileDialog.Filter("Text Files (*.txt)"));
		this.loadParameterFileTextBox.setText(filename);
		if(filename.isEmpty()){
			System.out.println("Empty");
			return;
		}
		ArrayList<String> parameters=new ArrayList<String>();
		try {
			BufferedReader reader=new BufferedReader(new FileReader(this.loadParameterFileTextBox.text()));
			String line;
			while((line=reader.readLine())!=null){
				parameters.add(line);
			}
			this.workingDirTextBox.setText(parameters.get(0));
			this.usernameMySQLTextBox.setText(parameters.get(1));
			this.passwordMySQLTextBox.setText(parameters.get(2));
			this.hostMySQLTextBox.setText(parameters.get(3));
			this.databaseMySQLTextBox.setText(parameters.get(4));
			this.RPathTextBox.setText(parameters.get(5));
			this.HaploviewPathTextBox.setText(parameters.get(6));
			this.generalBox.setEnabled(true);
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void browseWorkingDir(){
		String directory=QFileDialog.getExistingDirectory(this,tr("Choose directory"),null);
		this.workingDirTextBox.setText(directory+"/");
	}
	public void browseHaploviewPath(){
		String file=QFileDialog.getOpenFileName(this,tr("Choose R executable"),null);
		this.HaploviewPathTextBox.setText(file);
	}
	public void browseRPath(){
		String file=QFileDialog.getOpenFileName(this,tr("Choose Haploview executable"),null);
		this.RPathTextBox.setText(file);
	}
	public void saveParameters(String filename){
		if(filename.isEmpty())
			return;
		try {
			BufferedWriter writer=new BufferedWriter(new FileWriter(filename));
			writer.write(this.workingDirTextBox.text()+"\n");
			writer.write(this.usernameMySQLTextBox.text()+"\n");
			writer.write(this.passwordMySQLTextBox.text()+"\n");
			writer.write(this.hostMySQLTextBox.text()+"\n");
			writer.write(this.databaseMySQLTextBox.text()+"\n");
			writer.write(this.RPathTextBox.text()+"\n");
			writer.write(this.HaploviewPathTextBox.text()+"\n");
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}	
	public void setVisibilityChoiceSaveParameterFile(){
		if(this.saveParametersCheckBox.isChecked()){
			this.saveParameterFileTextBox.setVisible(true);
			this.browseSaveFileButton.setVisible(true);
		}
		else{
			this.saveParameterFileTextBox.setVisible(false);
			this.browseSaveFileButton.setVisible(false);
		}
	}
	public void setVisibilityChoiceLoadParameterFile(){
		if(this.loadParametersCheckBox.isChecked()){
			this.loadParameterFileTextBox.setVisible(true);
			this.browseLoadFileButton.setVisible(true);
			this.generalBox.setEnabled(false);
		}
		else{
			this.loadParameterFileTextBox.setVisible(false);
			this.browseLoadFileButton.setVisible(false);
			this.generalBox.setEnabled(true);
		}
	}
	
	public void handleErrors(String errorMsg){
		QMessageBox box=new QMessageBox(QMessageBox.Icon.Warning,"Error",errorMsg);
		box.show();
	}
}