/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package gui;

import com.trolltech.qt.core.*;
import com.trolltech.qt.core.QIODevice.OpenModeFlag;
import com.trolltech.qt.gui.*;
import com.trolltech.qt.network.QHttp;
import com.trolltech.qt.network.QHttpResponseHeader;
import com.trolltech.qt.webkit.QWebPage.LinkDelegationPolicy;
import com.trolltech.qt.webkit.QWebView;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class Browser extends QWebView {
	/**
	 * Http request object
	 */
	QHttp http;
	/**
	 * Filename of the file in which to save a downloaded page
	 */
	String filename;
	QProgressBar progressBar;
	QDialog progressBarDialog;
	boolean toDownload;
	QLabel loading;
	String shortMessage;
	String longMessage;

	/**
	 * Constructor
	 */
    public Browser() {
    	this.shortMessage="Loading...";
    	this.longMessage="Loading UCSC Genome Browser...To upload the custom track click on add custom track";
    	this.toDownload=false;
    	http=new QHttp();
    	this.filename="";       
        this.page().setLinkDelegationPolicy(LinkDelegationPolicy.DelegateAllLinks);
        this.page().linkClicked.connect(this,"download(QUrl)");
        // Initialize Progress Bar
        this.progressBarDialog=new QDialog();
        this.progressBarDialog.setWindowTitle("Progress");
        QVBoxLayout layout=new QVBoxLayout();
        loading=new QLabel(this.shortMessage);
        this.progressBar=new QProgressBar();
        layout.addWidget(loading);
        layout.addWidget(this.progressBar);
        this.progressBarDialog.setLayout(layout);
    	this.page().loadProgress.connect(this,"loadProgress(int )");
    	this.page().loadFinished.connect(this,"loadFinished()");
    	this.page().loadStarted.connect(this,"loadStarted()");
    	this.setDefaultUrl();
    }
    /**
     * Set the Web Browser url
     * @param url address to which the browser should be redirected
     */
    public void setUrl(String url){
    	if(this.url().toString().compareTo(url)!=0){
    		this.loading.setText(this.longMessage);
    		this.load(new QUrl(url));
    	}
    }
    /**
     * Redirect the browser to the UCSC Genome Browser home page
     */
    public void setDefaultUrl(){
    	this.load(new QUrl("http://genome.ucsc.edu/cgi-bin/hgGateway?hgsid=289527675"));
    }
    /**
     * Handle a download request
     */
    public void download(QUrl url){
    	String address=url.toString();
    	this.toDownload=false;
    	String extension=address.substring(address.lastIndexOf(".")+1);
    	if(extension.compareTo("pdf")==0){
    		this.filename=QFileDialog.getSaveFileName(this,tr("Save as..."),null,new QFileDialog.Filter("Pdf (*.pdf)"));
    		this.toDownload=true;
    	}
    	else if(extension.compareTo("eps")==0){
    		this.filename=QFileDialog.getSaveFileName(this,tr("Save as..."),null,new QFileDialog.Filter("Eps (*.eps)"));
    		this.toDownload=true;
    	}
    	else if(extension.compareTo("ps")==0){
    		this.filename=QFileDialog.getSaveFileName(this,tr("Save as..."),null,new QFileDialog.Filter("Ps (*.ps)"));
    		this.toDownload=true;
    	}
    	else{
    		this.load(url);
    	}
    	if(this.filename.compareTo("")==0)
    		return;
    	this.http=new QHttp();
    	http.responseHeaderReceived.connect(this,"responseHeader(QHttpResponseHeader)");
    	http.requestFinished.connect(this,"requestFinished(int,boolean)");
    	http.setHost(url.host());
    	http.get(url.path());
    }
    private void responseHeader(QHttpResponseHeader header){
    	System.out.println(header.contentLength());
    	System.out.println(header.contentType());
    	System.out.println(header.statusCode());
    }  
    /**
     * Download the file
     * @param id request
     * @param error true if there was an error handling the request
     */
    private void requestFinished(int id,boolean error){
    	if(error)
    		System.out.println("Error");
    	else{
    		if(this.toDownload==true){
	    		QFile pdf=new QFile(this.filename);
	    		if(pdf.open(OpenModeFlag.ReadWrite)){
	    			pdf.write(this.http.readAll());
	    			pdf.flush();
	    			pdf.close();
	    		}
	    		pdf.close();
    		}
    	}
    }
    private void loadStarted(){
    	this.progressBarDialog.show();
    }
    private void loadFinished(){
    	this.progressBarDialog.hide();
    	this.loading.setText(this.shortMessage);
    }
    private void loadProgress(int progress){
    	this.progressBar.setValue(progress); 	
    }
}