/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package gui;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.trolltech.qt.core.QThreadPool;
import com.trolltech.qt.core.Qt;
import com.trolltech.qt.gui.QApplication;
import com.trolltech.qt.gui.QCheckBox;
import com.trolltech.qt.gui.QComboBox;
import com.trolltech.qt.gui.QDialog;
import com.trolltech.qt.gui.QGroupBox;
import com.trolltech.qt.gui.QHBoxLayout;
import com.trolltech.qt.gui.QLabel;
import com.trolltech.qt.gui.QLineEdit;
import com.trolltech.qt.gui.QMessageBox;
import com.trolltech.qt.gui.QProgressBar;
import com.trolltech.qt.gui.QPushButton;
import com.trolltech.qt.gui.QVBoxLayout;

import core.ProcessingThreadArchitecture;
import core.RequestKey;
import core_server.LinkageDisequilibrium;
import core_server.MySQLConnection;
import exceptions.ConnectionErrorException;
import exceptions.ConnectionLostException;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class ArchitectureWindow extends QDialog{
	MainWindow mainWindow;
	QLineEdit geneTextBox;
	QLineEdit snpTextBox;
	QComboBox datasetBox;
	QComboBox geneKbp;
	QComboBox analysisType;
	QComboBox geneFormat;
	QComboBox genomeBuildBox;
	QComboBox mafBox;
	QGroupBox analysisBox;
	QGroupBox geneBox;
	QGroupBox snpBox;
	QGroupBox regionBox;
	QCheckBox geneIncludeSingletons;
	QCheckBox snpIncludeSingletons;
	QCheckBox regionIncludeSingletons;
	QCheckBox geneClusterHierarchically;
	QCheckBox regionClusterHierarchically;
	ProcessingThreadArchitecture processingThread;
	QDialog progressBarDialog;
	boolean error;
	QCheckBox colorByMAF;

	public ArchitectureWindow(MainWindow mainWindow){
		this.error=false;
		this.mainWindow=mainWindow;
		this.analysisType=new QComboBox();
		QVBoxLayout mainLayout=new QVBoxLayout();
		this.analysisBox=new QGroupBox("Analysis Type");
		this.geneBox=new QGroupBox("Gene");
		this.snpBox=new QGroupBox("SNP");
		this.regionBox=new QGroupBox("Region");
		this.snpBox.setEnabled(false);
		this.regionBox.setEnabled(false);
		
		this.analysisType.addItem("Gene");
		this.analysisType.addItem("SNP");
		this.analysisType.addItem("Region");
		this.analysisType.currentIndexChanged.connect(this,"chooseAnalysisType()");
		this.datasetBox=new QComboBox();
		this.genomeBuildBox=new QComboBox();
		this.datasetBox.currentIndexChanged.connect(this,"updateGenomeBuild()");
		try{
			this.loadDatasets();
		}catch(ConnectionLostException e){
			this.handleErrors(e.getMessage());
		}
		QLabel datasetLabel=new QLabel("Dataset");
		QLabel mafLabel=new QLabel("Minor allele frequency threshold");
		this.mafBox=new QComboBox();
		this.mafBox.addItem("0.0");
		this.mafBox.addItem("0.01");
		this.mafBox.addItem("0.05");
		this.mafBox.addItem("0.1");
		this.mafBox.setCurrentIndex(2);
		QLabel genomeBuildLabel=new QLabel("Genome Build");
		try{
			this.updateGenomeBuild();
		}catch(ConnectionLostException e){
			this.handleErrors(e.getMessage());
			this.close();
		}
		QHBoxLayout datasetLayout=new QHBoxLayout();
		datasetLayout.addWidget(datasetLabel,0,Qt.AlignmentFlag.AlignLeft);
		datasetLayout.addWidget(this.datasetBox,1,Qt.AlignmentFlag.AlignLeft);
		QPushButton deleteDatasetButton=new QPushButton("Delete dataset");
		datasetLayout.addWidget(deleteDatasetButton,1,Qt.AlignmentFlag.AlignLeft);
		deleteDatasetButton.clicked.connect(this,"deleteDataset()");
		datasetLayout.setSpacing(10);
		QHBoxLayout mafLayout=new QHBoxLayout();
		mafLayout.addWidget(mafLabel,0,Qt.AlignmentFlag.AlignLeft);
		mafLayout.addWidget(this.mafBox,1,Qt.AlignmentFlag.AlignLeft);
		mafLayout.setSpacing(10);
		QHBoxLayout genomeBuildLayout=new QHBoxLayout();
		genomeBuildLayout.addWidget(genomeBuildLabel,0,Qt.AlignmentFlag.AlignLeft);
		genomeBuildLayout.addWidget(this.genomeBuildBox,1,Qt.AlignmentFlag.AlignLeft);
		genomeBuildLayout.setSpacing(10);
		this.colorByMAF=new QCheckBox("Color by Minor Allele Frequency");
		
		QVBoxLayout analysisLayout=new QVBoxLayout();
		analysisLayout.addWidget(this.analysisType,1,Qt.AlignmentFlag.AlignTop);
		analysisLayout.addItem(datasetLayout);
		analysisLayout.addItem(mafLayout);
		analysisLayout.addItem(genomeBuildLayout);
		analysisLayout.addWidget(colorByMAF);
		analysisBox.setLayout(analysisLayout);
		
		QVBoxLayout geneLayout=new QVBoxLayout();
		this.geneFormat=new QComboBox();
		this.geneFormat.addItem("entrez_geneid");
		this.geneFormat.addItem("mrna_accession");
		this.geneFormat.addItem("symbol");
		this.geneFormat.setCurrentIndex(2);
		this.geneFormat.setMaximumWidth(150);
		this.geneTextBox=new QLineEdit();
		this.geneTextBox.setMaximumWidth(150);
		this.geneKbp=new QComboBox();
		QLabel geneKbpLabel=new QLabel("Max distance(kbp)");
		QHBoxLayout geneKbpLayout=new QHBoxLayout();
		this.geneKbp.addItem("0");
		this.geneKbp.addItem("10");
		this.geneKbp.addItem("25");
		this.geneKbp.addItem("50");
		this.geneKbp.addItem("100");
		this.geneKbp.addItem("250");
		this.geneKbp.addItem("500");
		geneKbpLayout.addWidget(geneKbpLabel,0,Qt.AlignmentFlag.AlignLeft);
		geneKbpLayout.addWidget(this.geneKbp,1,Qt.AlignmentFlag.AlignLeft);
		geneKbpLayout.setSpacing(10);
		QHBoxLayout geneTextBoxLayout=new QHBoxLayout();
		QLabel geneTextBoxLabel=new QLabel("ID");
		geneTextBoxLayout.addWidget(geneTextBoxLabel,0,Qt.AlignmentFlag.AlignLeft);
		geneTextBoxLayout.addWidget(geneTextBox,1,Qt.AlignmentFlag.AlignLeft);
		geneTextBoxLayout.setSpacing(10);
		geneLayout.addWidget(geneFormat);
		geneLayout.addItem(geneTextBoxLayout);
		geneLayout.addItem(geneKbpLayout);
		this.geneIncludeSingletons=new QCheckBox("Include singletons");
		geneLayout.addWidget(this.geneIncludeSingletons);
		this.geneClusterHierarchically=new QCheckBox("Cluster hierarchically");
		geneLayout.addWidget(this.geneClusterHierarchically);
		geneBox.setLayout(geneLayout);
		this.geneIncludeSingletons.stateChanged.connect(this,"enableDisableClusterHierachically()");
		this.geneClusterHierarchically.stateChanged.connect(this,"enableDisableIncludeSingletons()");
		
		QVBoxLayout snpLayout=new QVBoxLayout();
		this.snpTextBox=new QLineEdit();
		this.snpTextBox.setMaximumWidth(150);
		snpLayout.addWidget(snpTextBox);
		this.snpIncludeSingletons=new QCheckBox("Include singletons");
		snpLayout.addWidget(this.snpIncludeSingletons);
		snpBox.setLayout(snpLayout);
		
		QVBoxLayout regionLayout=new QVBoxLayout();
		this.regionIncludeSingletons=new QCheckBox("Include singletons");
		regionLayout.addWidget(this.regionIncludeSingletons);
		this.regionClusterHierarchically=new QCheckBox("Cluster hierarchically");
		regionLayout.addWidget(this.regionClusterHierarchically);
		regionBox.setLayout(regionLayout);
		
		QPushButton submitButton=new QPushButton("Create Clusters");
		submitButton.clicked.connect(this,"createArchitecture()");
		
		mainLayout.addWidget(analysisBox,1,Qt.AlignmentFlag.AlignTop);
		mainLayout.addWidget(geneBox,1,Qt.AlignmentFlag.AlignTop);
		mainLayout.addWidget(snpBox,1,Qt.AlignmentFlag.AlignTop);
		mainLayout.addWidget(regionBox,1,Qt.AlignmentFlag.AlignTop);
		mainLayout.addWidget(submitButton,1,Qt.AlignmentFlag.AlignLeft);
		this.setLayout(mainLayout);
		this.setWindowTitle("LD Architecure");
		this.show();
	}	
	
	public void chooseAnalysisType(){
		String checked=this.analysisType.currentText();
		this.geneBox.setEnabled(false);
		this.snpBox.setEnabled(false);
		this.regionBox.setEnabled(false);
		if(checked.compareTo("Gene")==0)
			this.geneBox.setEnabled(true);
		if(checked.compareTo("SNP")==0)
			this.snpBox.setEnabled(true);
		if(checked.compareTo("Region")==0)
			this.regionBox.setEnabled(true);
	}
	public void createArchitecture(){
		// Progress Bar
		String checked=this.analysisType.currentText();
		if(checked.compareTo("Chr")!=0){
			this.progressBarDialog=new QDialog();
			QVBoxLayout progressBarLayout=new QVBoxLayout();
			progressBarDialog.setWindowTitle("Progress");
			QProgressBar progressBar=new QProgressBar();
			QLabel progressLabel=new QLabel("Processing...");
			progressLabel.setAlignment(Qt.AlignmentFlag.AlignLeft);
			progressBarLayout.addWidget(progressLabel);
			progressBar.setAlignment(Qt.AlignmentFlag.AlignHCenter);
			progressBar.setMinimum(0);
			progressBar.setMaximum(0);
			progressBarLayout.addWidget(progressBar);
			this.progressBarDialog.setLayout(progressBarLayout);
	        this.progressBarDialog.show();
			this.update();
			this.repaint();
			QApplication.processEvents();
		}
		if(checked.compareTo("Gene")==0){
			String name=this.geneTextBox.text()+"-"+this.datasetBox.currentText()+
			"-maf"+this.mafBox.currentText()+"-kbp"+this.geneKbp.currentText()+"-"+this.genomeBuildBox.currentText();
			if(this.geneIncludeSingletons.isChecked())
				name=name+"-singletons";
			if(this.geneClusterHierarchically.isChecked())
				name=name+"-hierarchical";
			RequestKey requestKey=new RequestKey();
			String connString="?type=Gene&dataset="+this.datasetBox.currentText()+
			"&maf="+Double.parseDouble(this.mafBox.currentText())+
			"&format="+this.geneFormat.currentText()+
			"&id="+this.geneTextBox.text()+
			"&singletons="+this.geneIncludeSingletons.isChecked()+
			"&maxdist="+Integer.parseInt(this.geneKbp.currentText())+
			"&genomebuild="+this.genomeBuildBox.currentText()+
			"&hierarchical="+this.geneClusterHierarchically.isChecked()+
			"&requestkey="+requestKey.getKey()+
			"&colorbyfreq="+this.colorByMAF.isChecked()+
			"&haplotypes=false";
			this.sendRequest(connString,requestKey,name);
			this.close();
		}
		if(checked.compareTo("SNP")==0){			
			this.close();
			String name=this.snpTextBox.text()+"-"+this.datasetBox.currentText()+
			"-maf"+this.mafBox.currentText()+"-"+this.genomeBuildBox.currentText();
			if(this.snpIncludeSingletons.isChecked())
				name=name+"-singletons";
			RequestKey requestKey=new RequestKey();
			String connString="?type=SNP&dataset="+this.datasetBox.currentText()+
			"&maf="+Double.parseDouble(this.mafBox.currentText())+
			"&rs="+this.snpTextBox.text()+
			"&singletons="+this.snpIncludeSingletons.isChecked()+
			"&genomebuild="+this.genomeBuildBox.currentText()+
			"&requestkey="+requestKey.getKey()+
			"&colorbyfreq="+this.colorByMAF.isChecked()+
			"&haplotypes=false";
			this.sendRequest(connString,requestKey,name);
			this.close();
		}
		if(checked.compareTo("Region")==0){
			this.repaint();
			QApplication.processEvents();
			String name="region"+"-"+this.datasetBox.currentText()+
			"-maf"+this.mafBox.currentText()+"-"+this.genomeBuildBox.currentText();
			if(this.regionIncludeSingletons.isChecked())
				name=name+"-singletons";
			if(this.regionClusterHierarchically.isChecked())
				name=name+"-hierarchical";
			RequestKey requestKey=new RequestKey();
			String connString="?type=Region&dataset="+this.datasetBox.currentText()+
			"&maf="+Double.parseDouble(this.mafBox.currentText())+
			"&singletons="+this.regionIncludeSingletons.isChecked()+
			"&genomebuild="+this.genomeBuildBox.currentText()+
			"&hierarchical="+this.regionClusterHierarchically.isChecked()+
			"&requestkey="+requestKey.getKey()+
			"&colorbyfreq="+this.colorByMAF.isChecked()+
			"&haplotypes=false";
			this.sendRequest(connString,requestKey,name);
			this.close();
		}
	}
	
	private void enableDisableClusterHierachically(){
		if(this.geneIncludeSingletons.isChecked()){
			this.geneClusterHierarchically.setChecked(false);
			this.geneClusterHierarchically.setEnabled(false);
		}else{
			this.geneClusterHierarchically.setEnabled(true);
		}
	}
	
	private void enableDisableIncludeSingletons(){
		if(this.geneClusterHierarchically.isChecked()){
			this.geneIncludeSingletons.setChecked(false);
			this.geneIncludeSingletons.setEnabled(false);
		}else{
			this.geneIncludeSingletons.setEnabled(true);
		}
	}
	
	private void sendRequest(String connString,RequestKey requestKey,String name){
		this.processingThread=new ProcessingThreadArchitecture(this.mainWindow.getServer(),connString,this.analysisType.currentText(),
				requestKey,name);
		this.processingThread.getError().connect(this,"handleErrorsServerSide(String)");
		this.processingThread.getGeneArchitectureComputed().connect(this,"addArchitecture(RequestKey,String,String)");
		QThreadPool pool=new QThreadPool();
		pool.start(this.processingThread);
	}
	
	private void handleErrorsServerSide(String errorMsg){
		this.progressBarDialog.hide();
		QMessageBox box=new QMessageBox(QMessageBox.Icon.Warning,"Error",errorMsg);
		box.show();
		this.error=true;
		System.out.println("Server");
	}
	
	private void handleErrors(String errorMsg){
		QMessageBox box=new QMessageBox(QMessageBox.Icon.Warning,"Error",errorMsg);
		box.show();
		System.out.println("Client");
		this.close();
	}
	
	private void addArchitecture(RequestKey requestKey,String name,String type){
		if(this.error==false){
			this.progressBarDialog.hide();
			if(type.compareTo("Gene")==0)
				this.mainWindow.getNavigationTree().addArchitecture(requestKey,"Gene",this.geneIncludeSingletons.isChecked(),name,this.colorByMAF.isChecked());
			if(type.compareTo("SNP")==0)
				this.mainWindow.getNavigationTree().addArchitecture(requestKey,"SNP",this.snpIncludeSingletons.isChecked(),name,this.colorByMAF.isChecked());
			if(type.compareTo("Region")==0)
				this.mainWindow.getNavigationTree().addArchitecture(requestKey,"Region",this.regionIncludeSingletons.isChecked(),name,this.colorByMAF.isChecked());
		}
	}
	
	private void loadDatasets() throws ConnectionLostException{
		this.datasetBox.clear();
		MySQLConnection conn=this.mainWindow.getServer().getMySQLConnection();
		Statement stmt;
		try {
			stmt = conn.getConnection().createStatement();
			ResultSet rs=stmt.executeQuery("SELECT prefix FROM datasets");
			while(rs.next()){
				String dataset=rs.getString("prefix");
				if(dataset!=null)
					this.datasetBox.addItem(dataset);
			}
			rs.close();
			stmt.close();
		} catch (SQLException e) {
			throw new ConnectionLostException(e);
		}
	}
	
	private void updateGenomeBuild() throws ConnectionLostException{
		this.genomeBuildBox.clear();
		MySQLConnection conn=this.mainWindow.getServer().getMySQLConnection();
		Statement stmt;
		try {
			stmt = conn.getConnection().createStatement();
			ResultSet rs=stmt.executeQuery("SELECT genome_build FROM datasets WHERE prefix='"+
					this.datasetBox.currentText()+"'");
			while(rs.next()){
				this.genomeBuildBox.addItem(rs.getString("genome_build"));
			}
		} catch (SQLException e) {
			throw new ConnectionLostException(e);
		}
	}
	
	private void deleteDataset(){
		LinkageDisequilibrium ld=new LinkageDisequilibrium(this.mainWindow.getServer().getMySQLConnection(),this.mainWindow);
		try{
			ld.deleteDataset(this.datasetBox.currentText());
			this.loadDatasets();
			if(this.datasetBox.count()==0){
				QMessageBox box=new QMessageBox(QMessageBox.Icon.Warning,"Warning","All datasets have been removed. " +
						"Please load a new dataset to create a new architecture.");
				box.show();
				this.mainWindow.disableNewArchitectureAction();
				this.close();
			}else{
				QMessageBox box=new QMessageBox(QMessageBox.Icon.NoIcon,"Dataset","Dataset deleted!");
				box.show();
			}
		}catch(ConnectionLostException e){
			this.handleErrors(e.getMessage());
		}
	}
}