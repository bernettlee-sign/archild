/*
    ArchiLD is a software for the hierarchical visualization of clusters 
    of SNPs in perfect linkage disequilibrium (LD).
    Copyright (C) 2012 Singapore Immunology Network, A*STAR
    Contact: Michael Poidinger (michael_poidinger@immunol.a-star.edu.sg)

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
package gui;

import com.trolltech.qt.core.Qt.TextFormat;
import com.trolltech.qt.gui.QDialog;
import com.trolltech.qt.gui.QGroupBox;
import com.trolltech.qt.gui.QLabel;
import com.trolltech.qt.gui.QVBoxLayout;

/**
 * 
 * @author Rossella Melchiotti (rossella_melchiotti@immunol.a-star.edu.sg)
 *
 */
public class AboutWindow extends QDialog{
	public AboutWindow(){
		this.setWindowTitle("ArchiLDCustom Version 1.0");
		QVBoxLayout mainLayout=new QVBoxLayout();
		// First block
		QGroupBox firstBlock=new QGroupBox();
		QVBoxLayout firstBlockLayout=new QVBoxLayout();
		firstBlockLayout.addWidget(new QLabel("Singapore Immunology Network"));
		firstBlockLayout.addWidget(new QLabel("8A Biomedical Grove, Immunos Building"));
		firstBlockLayout.addWidget(new QLabel("Singapore 138648"));
		QLabel signWebsite=new QLabel();
		signWebsite.setOpenExternalLinks(true);
		signWebsite.setTextFormat(TextFormat.RichText);
		signWebsite.setText("<html> <a href ='http://www.sign.a-star.edu.sg/'>http://www.sign.a-star.edu.sg/</a></html>");		
		firstBlockLayout.addWidget(signWebsite);
		firstBlock.setLayout(firstBlockLayout);
		mainLayout.addWidget(firstBlock);
		// Second block
		QGroupBox secondBlock=new QGroupBox();
		QVBoxLayout secondBlockLayout=new QVBoxLayout();
		secondBlockLayout.addWidget(new QLabel("Melchiotti R.,Rötzschke O.,Poidinger M."));
		secondBlockLayout.addWidget(new QLabel("ArchiLD: hierarchical visualization of" +
				" linkage disequilibrium in human populations"));
		secondBlock.setLayout(secondBlockLayout);
		mainLayout.addWidget(secondBlock);
		//Third block
		QGroupBox thirdBlock=new QGroupBox();
		QVBoxLayout thirdBlockLayout=new QVBoxLayout();
		thirdBlockLayout.addWidget(new QLabel("Written by Rossella Melchiotti"));
		thirdBlockLayout.addWidget(new QLabel("July,15 2013"));
		QLabel downloadWebsite=new QLabel();
		downloadWebsite.setOpenExternalLinks(true);
		downloadWebsite.setTextFormat(TextFormat.RichText);
		downloadWebsite.setText("<html> <a href ='http://archild.sign.a-star.edu.sg'>Website</a></html>");	
		thirdBlockLayout.addWidget(downloadWebsite);
		thirdBlock.setLayout(thirdBlockLayout);
		mainLayout.addWidget(thirdBlock);		
		this.setLayout(mainLayout);
		this.show();
	}
}
